Simulation Models :: common
---------------------------

These hoc and mod files implement common cell mechanisms used in BBP.

They are expected to be extended by specific models available in their own
repositories, e.g.: sim/models/neocortex


Versions
--------

2019.1 - First import after splitting of neurodamus and models

