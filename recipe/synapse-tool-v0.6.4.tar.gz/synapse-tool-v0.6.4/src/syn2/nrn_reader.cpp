/*
 * Copyright (C) 2017 Adrien Devresse <adrien.devresse@epfl.ch>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
#include "nrn_reader.hpp"
#include <syn2/synapses_exceptions.hpp>

#include <boost/filesystem.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/numeric/ublas/matrix_proxy.hpp>
#include <highfive/H5Exception.hpp>

#include <functional>
#include <iostream>


namespace fs = ::boost::filesystem;

namespace syn2 {


//////////////////////////////////////////////////////////////
/// Nrn Specific Properties
///
namespace nrn_specific_property {

const std::string morpho_segment_id_post() {
    return "morpho_segment_id_post";
}
const std::string morpho_segment_id_pre() {
    return "morpho_segment_id_pre";
}
const std::string morpho_offset_segment_post() {
    return "morpho_offset_segment_post";
}
const std::string morpho_offset_segment_pre() {
    return "morpho_offset_segment_pre";
}
const std::string morpho_type_id_pre() {
    return "morpho_type_id_pre";
}
const std::string morpho_branch_order_dend() {
    return "morpho_branch_order_dend";
}
const std::string morpho_branch_order_axon() {
    return "morpho_branch_order_axon";
}
const std::string n_rrp_vesicles() {
    return "n_rrp_vesicles";
}
const std::string morpho_section_type_post() {
    return "morpho_section_type_post";
}
const std::string nrn_line() {
    return "nrn_line";
}

} //namespace nrn_specific_property


//////////////////////////////////////////////////////////////
/// Nrn Fields
///

const int NRN_VERSION_WITH_NRRP = 5;


struct NrnField {
    int column;
    int n_cols;
    property_type type;
    const std::string name;
};


static const std::vector<NrnField> nrn_fields{
  {0, 1, property_type::vec_uint, property::connected_neurons_pre()},
  {1, 1, property_type::vec_double, property::delay()},
  {2, 1, property_type::vec_int, property::morpho_section_id_post()},
  {3, 1, property_type::vec_int, nrn_specific_property::morpho_segment_id_post()},
  {4, 1, property_type::vec_double, nrn_specific_property::morpho_offset_segment_post()},
  {5, 1, property_type::vec_int, property::morpho_section_id_pre()},
  {6, 1, property_type::vec_int, nrn_specific_property::morpho_segment_id_pre()},
  {7, 1, property_type::vec_double, nrn_specific_property::morpho_offset_segment_pre()},
  {8, 1, property_type::vec_double, property::conductance()},
  {9, 1, property_type::vec_double, property::u_syn()},
  {10, 1, property_type::vec_double, property::depression_time()},
  {10, 1, property_type::vec_int, property::junction_id_pre()},
  {11, 1, property_type::vec_double, property::facilitation_time()},
  {11, 1, property_type::vec_int, property::junction_id_post()},
  {12, 1, property_type::vec_double, property::decay_time()},
  {13, 1, property_type::vec_int, property::syn_type_id()},
  {14, 1, property_type::vec_int, nrn_specific_property::morpho_type_id_pre()},
  {15, 1, property_type::vec_int, nrn_specific_property::morpho_branch_order_dend()},
  {16, 1, property_type::vec_int, nrn_specific_property::morpho_branch_order_axon()},
  {17, 1, property_type::vec_int, property::absolute_efficacy()},
  {17, 1, property_type::vec_int, nrn_specific_property::n_rrp_vesicles()},
  {18, 1, property_type::vec_int, nrn_specific_property::morpho_section_type_post()},

  // position dataset
  {1, 3, property_type::mat_double, property::position_contour_pre()},
  {4, 3, property_type::mat_double, property::position_contour_post()},
  {7, 3, property_type::mat_double, property::position_center_pre()},
  {10, 3, property_type::mat_double, property::position_center_post()}};


//////////////////////////////////////////////////////////////
/// NRN Internals
///

std::vector<std::string> list_all_neuron_dataset(const HighFive::File& nrn_file) {
    std::vector<std::string> list_names = nrn_file.listObjectNames();

    auto end_it = std::remove_if(list_names.begin(), list_names.end(),
                                 [&](const std::string& str) { return (str[0] != 'a'); });

    list_names.resize(std::distance(list_names.begin(), end_it));
    return list_names;
}


std::vector<std::size_t> list_all_neuron_ids(const HighFive::File& nrn_file) {
    std::vector<std::string> all_names = list_all_neuron_dataset(nrn_file);
    std::vector<std::size_t> all_ids(all_names.size());

    std::transform(
      all_names.begin(), all_names.end(), all_ids.begin(), [](const std::string& str) {
          try {
              if (str.size() < 1) {
                  throw std::invalid_argument("invalid string length for nrn dataset");
              }

              std::size_t neuron_id = boost::lexical_cast<std::size_t>(
                str.c_str() + 1); // skip 'a' and lexical_cast
              neuron_id -=
                1; // identifiy neuron starting from 0, contrary to nrn.h5 to be consistent with other file format
              return neuron_id;

          } catch (std::exception& e) {
              throw syn_exception(error_code::invalid_dataset_name,
                                  std::string("invalid dataset name for /aX ") + str + " " +
                                    e.what());
          }
      });

    std::sort(all_ids.begin(), all_ids.end());
    return all_ids;
}


int get_nrn_version(const HighFive::File& nrn_file) {
    if (!nrn_file.exist("info")) {
        //std::cerr << "[SynapseTool] Warning: File has no info dataset. Version=0\n";
        return 0;
    }

    HighFive::DataSet info_ds = nrn_file.getDataSet("info");

    int version = 0;
    if (info_ds.hasAttribute("version")) {
        info_ds.getAttribute("version").read(version);
    } else {
        //std::cerr << "[SynapseTool] Warning: File info has no version Attribute. Version=0\n";
    }

    return version;
}


//////////////////////////////////////////////////////////////
/// Data Handling & extractors
///

inline static void check_dimensions(const std::vector<std::size_t>& dims) {
    if (dims.size() != 2) {
        throw syn_exception(error_code::invalid_layout,
                            "nrn file format dataset /aX should have only 2 dimensions");
    }
}


inline static void check_nrn_matrix(const nrn_reader::raw_data_mat& mat) {
    // check if hardcoded nrn or nrn position number of column match
    if (mat.size1() > 0 && mat.size2() != 19 && mat.size2() != 13) {
        throw syn_exception(error_code::invalid_layout,
                            "nrn file format dataset inside nrn.h5 should have 19 columns");
    }
}


class concat_generic_vector : public boost::static_visitor<> {
public:
    template <typename T, typename Y>
    void operator()(T& vec_out, const Y& vec_in) {
        (void)vec_out;
        (void)vec_in;
        throw syn_exception(error_code::invalid_layout,
                            std::string("shoud not concat different type of property ") +
                              typeid(vec_in).name() + " " + typeid(vec_out).name());
    }

    template <typename T>
    void operator()(T& vec_out, const T& vec_in) {
        size_t num_elems = vec_out.size() + vec_in.size();
        if (vec_out.capacity() < num_elems)
            vec_out.reserve(num_elems * 1.5); // Reserve 50% more for perf
        std::copy(vec_in.begin(), vec_in.end(), std::back_inserter(vec_out));
    }

    void operator()(mat_double& out, const mat_double& in) {
        // Empty Matrix we dont know the width
        if (in.size1() == 0)
            return;
        if (out.size1() == 0) {
            out = std::move(in);
            return;
        }
        if (out.size2() != in.size2()) {
            throw syn_exception(error_code::invalid_layout,
                                "try to merge two matrix with different column layout");
        }

        const std::size_t old_number_lines = out.size1();
        out.resize(old_number_lines + in.size1(), out.size2(), true);

        for (std::size_t i = 0; i < in.size1(); ++i) {
            for (std::size_t j = 0; j < in.size2(); ++j) {
                out(old_number_lines + i, j) = in(i, j);
            }
        }
    }
};


void concat_properties(property_vec& out, property_vec& other) {
    if (out.which() != other.which()) {
        throw syn_exception(error_code::invalid_layout,
                            "two concatenated properties are from different types");
    }

    concat_generic_vector visitor;
    boost::apply_visitor(visitor, out, other);
}


template <typename Vector>
property_vec extract_nrn_column(const nrn_reader::raw_data_mat& mat,
                                std::size_t column_number) {
    using boost::numeric::ublas::matrix_column;
    typedef typename Vector::value_type dest_type;

    if (mat.size1() == 0) {
        return property_vec(Vector());
    }

    check_nrn_matrix(mat);

    Vector resu;
    matrix_column<const nrn_reader::raw_data_mat> column(mat, column_number);
    resu.reserve(column.size());

    if (column_number == 0) {
        // pre-ids require subtracting 1 to make E [0, N[
        for (const float& v : column) {
            resu.emplace_back(dest_type(v) - 1);
        }
    } else {
        for (const float& v : column) {
            resu.emplace_back(dest_type(v));
        }
    }

    return property_vec(resu);
}


template <typename Matrix>
property_vec extract_nrn_columns(const nrn_reader::raw_data_mat& mat,
                                 std::size_t column_number_start,
                                 std::size_t column_number_end) {
    typedef typename Matrix::value_type mat_val_type;

    if (mat.size1() == 0) {
        return property_vec(Matrix());
    }

    assert(column_number_end >= column_number_start);
    check_nrn_matrix(mat);

    Matrix resu;
    resu.resize(mat.size1(), column_number_end - column_number_start);

    for (std::size_t i = 0; i < mat.size1(); ++i) {
        for (std::size_t j = column_number_start; j < column_number_end; ++j) {
            resu(i, (j - column_number_start)) = mat_val_type(mat(i, j));
        }
    }
    return property_vec(resu);
}


//////////////////////////////////////////////////////////////
/// Nrn_reader methods
///

nrn_reader::nrn_reader(const std::string& directory, const options& opts)
      : _dirname(directory)
      , _number_synapse(0)
      , _all_neuron_ids()
      , _verbose(opts.is_verbose())
      , _nrn_file()
      , _nrn_position_file()
      , _init_count()
      , _property_mapper()
      , _cur_dataset({size_t(-1), raw_data_mat()}) {
    std::string nrn_filename(_dirname);

    // Though not standard, shall handle single file (not dir) with arbitrary name
    if (fs::is_directory(_dirname)) {
        nrn_filename = _dirname + "/nrn.h5";
        std::string nrn_position_filename = _dirname + "/nrn_positions.h5";

        if (fs::exists(nrn_position_filename)) {
            std::lock_guard<std::mutex> _l(hdf5_lock());
            _nrn_position_file.reset(new HighFive::File(nrn_position_filename));
        }
    }

    try {
        std::lock_guard<std::mutex> _l(hdf5_lock());
        _nrn_file.reset(new HighFive::File(nrn_filename));

    } catch (std::exception& e) {
        throw syn_exception(error_code::file_access_error,
                            std::string("Unable to open nrn file ") + nrn_filename + ": " +
                              e.what());
    }

    // proper logic to extract nrn_line
    _property_mapper[nrn_specific_property::nrn_line()] = get_property_fun(
      [&, this](const std::size_t id_post, const selection&) {
          std::vector<std::int64_t> lines(this->get_number_synapses_post_id(id_post));
          std::iota(lines.begin(), lines.end(), 0);
          return property_vec(std::move(lines));
      });

    _property_mapper[property::synapse_index()] = get_property_fun(
      [&, this](const std::size_t id_post, const selection&) {
          std::vector<std::uint64_t> lines(this->get_number_synapses_post_id(id_post));
          std::size_t syn_offset = get_synapse_offset_post_id(id_post);
          for (auto i = 0ul; i < lines.size(); i++) {
              lines[i] = syn_offset + i;
          }
          return property_vec(std::move(lines));
      });

    // nrn: synapse_id is just an alias to synapse_index
    _property_mapper[property::synapse_id()] = _property_mapper[property::synapse_index()];

    // proper logic to extract post id
    _property_mapper[property::connected_neurons_post()] = get_property_fun(
      [&, this](const std::size_t id_post, const selection&) {
          const std::size_t real_neuron_id = id_post;
          return property_vec(
            vec_uint(this->get_number_synapses_post_id(id_post), real_neuron_id));
      });


    // Populate _property_mapper for all regular fields in the dataset

    for (const NrnField& field : nrn_fields) {
        switch (field.type) {
            case property_type::vec_int:
                _property_mapper[field.name] = get_property_fun(
                  [&, this](const std::size_t id_post, const selection&) {
                      return extract_nrn_column<vec_int>(
                        this->get_data_for_post_id(id_post), field.column);
                  });
                break;
            case property_type::vec_uint:
                _property_mapper[field.name] = get_property_fun(
                  [&, this](const std::size_t id_post, const selection&) {
                      return extract_nrn_column<vec_uint>(
                        this->get_data_for_post_id(id_post), field.column);
                  });
                break;
            case property_type::vec_double:
                _property_mapper[field.name] = get_property_fun(
                  [&, this](const std::size_t id_post, const selection&) {
                      return extract_nrn_column<vec_double>(
                        this->get_data_for_post_id(id_post), field.column);
                  });
                break;
            case property_type::mat_double:
                _property_mapper[field.name] = get_property_fun(
                  [&, this](const std::size_t id_post, const selection&) {
                      return extract_nrn_columns<mat_double>(
                        this->get_data_for_post_id(id_post), field.column,
                        field.column + field.n_cols);
                  });
                break;
            case property_type::vec_byte:
                // not used
                break;
        }
    }
}


std::size_t nrn_reader::get_number_synapses() {
    std::lock_guard<std::mutex> _l(hdf5_lock());

    init_metadata();
    return _number_synapse;
}


std::size_t nrn_reader::get_number_synapses_post_id(std::size_t id_post) {
    // Non-existing post-gid would throw, even though just means 0 count
    try {
        const auto& dataset_name = std::string("/a") + std::to_string(id_post + 1);
        if (! _nrn_file->exist(dataset_name)) {
            return 0;
        }
        auto dims = this->_nrn_file
                      ->getDataSet(dataset_name)
                      .getSpace()
                      .getDimensions();
        check_dimensions(dims);
        return dims[0];
    } catch (const HighFive::DataSetException&) {
        return 0;
    }
}


void nrn_reader::init_metadata() {
    std::call_once(_init_count, [this]() {
        std::size_t res = 0;
        // nrn does not give any way to list the number of synapses ...
        // we have to list the number of dataset and iterate on eveyr on them
        std::vector<std::size_t> list_ids = list_all_neuron_ids(*_nrn_file);

        for (const std::size_t id : list_ids) {
            res += this->get_number_synapses_post_id(id);
        }

        _number_synapse = res;
        _all_neuron_ids.swap(list_ids);
    });
}


const std::vector<std::size_t>& nrn_reader::get_all_ids_pre() {
    init_metadata();
    return _all_neuron_ids;
}


property_vec nrn_reader::get_property(const std::string& property, const selection& slice) {
    std::lock_guard<std::mutex> _l(hdf5_lock());

    auto all_ranges = slice.all_synapse_ranges();
    if (!all_ranges.empty()) {
        throw syn_exception(error_code::operation_not_supported,
                            "Selection by range not supported for nrn");
    }

    auto all_post_ids = slice.post_synaptic_ids();
    if (!all_post_ids.empty()) {
        return get_single_property_post(property, all_post_ids[0]);
    }

    return get_all_property(property);
}


std::vector<std::string> nrn_reader::list_property_names(bool include_virtual) {
    int ver = get_nrn_version(*_nrn_file);
    std::vector<std::string> columns{
        property::connected_neurons_post(),
        property::connected_neurons_pre(),
        property::delay(),
        property::morpho_section_id_post(),
        nrn_specific_property::morpho_segment_id_post(),
        nrn_specific_property::morpho_offset_segment_post(),
        property::morpho_section_id_pre(),
        nrn_specific_property::morpho_segment_id_pre(),
        nrn_specific_property::morpho_offset_segment_pre(),
        property::conductance(),
        property::u_syn(),
        property::depression_time(),
        property::facilitation_time(),
        property::decay_time(),
        property::syn_type_id(),
        nrn_specific_property::morpho_type_id_pre(),
        nrn_specific_property::morpho_branch_order_dend(),
        nrn_specific_property::morpho_branch_order_axon(),
        (ver >= NRN_VERSION_WITH_NRRP) ? nrn_specific_property::n_rrp_vesicles()
                                       : property::absolute_efficacy(),
        nrn_specific_property::morpho_section_type_post(),
        nrn_specific_property::nrn_line()
    };
    if (include_virtual) {
        columns.push_back(property::synapse_index());
    }
    return columns;
}


std::vector<std::string> nrn_reader::list_populations() {
    return std::vector<std::string>{"default"};
}


void nrn_reader::select_population(const std::string& pop) {
    if (pop != std::string("default"))
        throw syn_exception(error_code::population_not_existing,
                            "Nrn format supports a single population (default)");
}


nrn_reader::get_property_fun& nrn_reader::resolve_property_fun(const std::string& property) {
    auto it = _property_mapper.find(property);

    if (it == _property_mapper.end()) {
        throw syn_exception(error_code::property_not_supported,
                            std::string("Property not supported in this file format ") +
                              _dirname + "/nrn.h5");
    }

    return it->second;
}

property_vec nrn_reader::get_single_property_post(const std::string& property,
                                                  uint64_t id) {
    get_property_fun& property_executor = resolve_property_fun(property);

    return property_executor(id, selection::by_post_neuron_id(id));
}

property_vec nrn_reader::get_all_property(const std::string& property) {
    std::vector<std::size_t> list_ids = get_all_ids_pre();
    bool need_concat = false;

    get_property_fun& property_executor = resolve_property_fun(property);

    property_vec res;

    for (const std::size_t post_neuron_id : list_ids) {
        property_vec local_properties;

        local_properties = property_executor(post_neuron_id, selection::all());

        if (!need_concat) {
            res.swap(local_properties);
            need_concat = true;
        } else {
            concat_properties(res, local_properties);
        }
    }

    return res;
}


nrn_reader::raw_data_mat& nrn_reader::get_data_for_post_id(std::size_t id) {
    /// Data is small enough to not be worth fetching a single column
    /// We can keep the matrix in memory for subsequent requests to other columns
    if (id == _cur_dataset.tgid) {
        return _cur_dataset.data;
    }

    // Check size to avoid reading inexisting dataset
    if (get_number_synapses_post_id(id) > 0) {
        _nrn_file->getDataSet(std::string("/a") + std::to_string(id + 1))
          .read(_cur_dataset.data);
    } else {
        _cur_dataset.data = raw_data_mat();
    }
    _cur_dataset.tgid = id;

    return _cur_dataset.data;
}


std::size_t nrn_reader::get_synapse_offset_post_id(std::size_t id, bool cache) {
    if (id == 0ul) {
        return 0ul;
    }
    if (id == _synapse_offset_cache.first) {
        return _synapse_offset_cache.second;
    }
    if (cache) {
        _synapse_offset_cache = {id, get_number_synapses_post_id(id - 1) +
                                       get_synapse_offset_post_id(id - 1, false)};
        return _synapse_offset_cache.second;
    }
    // Avoid always caching to enable recursion tail optimization
    return get_number_synapses_post_id(id - 1) + get_synapse_offset_post_id(id - 1, false);
}

} // namespace syn2
