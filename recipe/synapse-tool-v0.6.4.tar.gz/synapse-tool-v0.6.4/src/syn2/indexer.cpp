/*
 * Copyright (C) 2017-2020 Blue Brain Project
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */
#include "indexer.hpp"
#include "progress.hpp"

#include <algorithm>
#include <functional>
#include <memory>

#ifdef SYNTOOL_WITH_MPI
#include <mpi-cpp/mpi.hpp>
#include <mpi.h>
#endif

// Used to tune how many neurons are processed in each MPI communications block
constexpr uint64_t GATHER_BLOCK_SIZE = 256;
// Used to determine how many neurons are indexed before they are written to disk
constexpr uint64_t WRITE_BLOCK_SIZE = 16 * 1024;

namespace {

class WriteBuffer {
  public:
    WriteBuffer(HighFive::DataSet& ids, HighFive::DataSet& ranges, uint64_t trigger)
        : ids_(ids), ranges_(ranges), trigger_(trigger) {}

    ~WriteBuffer() {
        write(0);
    }

    void add(const syn2::NeuronIndex::neuron_ranges_t& ranges) {
        if (ranges.empty()) {
            // id_buffer_ maps from neuron id to ranges. Push an empty range if we don't
            // point to anything.
            id_buffer_.emplace_back(0, 0);
        } else {
            const auto current_offset = range_offset_ + range_buffer_.size();
            id_buffer_.emplace_back(current_offset, current_offset + ranges.size());
            range_buffer_.insert(std::end(range_buffer_), std::begin(ranges), std::end(ranges));
        }

        write(trigger_);
    }

  private:
    void write(uint64_t trigger) {
        if (id_buffer_.size() < trigger || id_buffer_.empty()) {
            return;
        }

        ids_.select({id_offset_, 0}, {id_buffer_.size(), 2}).write_raw<syn2::index_type>(&id_buffer_[0].first);
        ranges_.select({range_offset_, 0}, {range_buffer_.size(), 2}).write_raw<syn2::index_type>(&range_buffer_[0].first);

        id_offset_ += id_buffer_.size();
        range_offset_ += range_buffer_.size();

        id_buffer_.clear();
        range_buffer_.clear();
    }

    HighFive::DataSet& ids_;
    HighFive::DataSet& ranges_;

    const uint64_t trigger_ = 1024;

    syn2::NeuronIndex::neuron_ranges_t id_buffer_{};
    syn2::NeuronIndex::neuron_ranges_t range_buffer_{};

    uint64_t id_offset_ = 0;
    uint64_t range_offset_ = 0;
};

}

namespace syn2 {

void NeuronIndex::update_or_add_new_range(std::uint64_t id, std::uint64_t line) {
    resize_if_needed(id);
    neuron_ranges_t& multirange = data_[id];

    if (multirange.size() > 0 && multirange.back().second == line) {
        multirange.back().second = line + 1;
    } else {
        multirange.emplace_back(line, line + 1);
        length_++;
    }
}

inline void NeuronIndex::resize_if_needed(std::uint64_t id) {
    if (id >= data_.size()) {
        data_.resize(id + 1);
    }
}

void NeuronIndex::index_ids(const index_type* raw_ids,
                            uint64_t length,
                            const uint64_t offset) {
    for (uint64_t i = 0; i < length; i++) {
        update_or_add_new_range(raw_ids[i], offset + i);
    }
}

void NeuronIndex::index_ids(std::vector<index_type> ids, const uint64_t offset) {
    index_ids(ids.data(), ids.size(), offset);
}

matrix_index_raw NeuronIndex::compute_primary_index() {
    matrix_index_raw syn2_index(data_.size(), 2);

    index_type secondary_index_line = 0, syn2_index_line = 0;

    for (const neuron_ranges_t& ranges : data_) {
        if (ranges.size() == 0) {
            syn2_index(syn2_index_line, 0) = 0;
            syn2_index(syn2_index_line, 1) = 0;
        } else {
            syn2_index(syn2_index_line, 0) = secondary_index_line;
            secondary_index_line += ranges.size();
            syn2_index(syn2_index_line, 1) = secondary_index_line;
        }
        syn2_index_line++;
    }
    return syn2_index;
}

matrix_index_raw NeuronIndex::compute_secondary_index() {
    matrix_index_raw syn2_index;

    syn2_index.resize(length_, 2);

    uint64_t syn2_index_line = 0;

    for (const neuron_ranges_t& ranges : data_) {
        for (std::size_t i = 0; i < ranges.size(); ++i) {
            syn2_index(syn2_index_line, 0) = ranges[i].first;
            syn2_index(syn2_index_line, 1) = ranges[i].second;
            syn2_index_line++;
        }
    }
    return syn2_index;
}

template <class T>
NeuronIndex NeuronIndex::create_from_h5_dataset(const T& ds,
                                                uint64_t dataset_offset,
                                                bool with_progress) {
    static const size_t BLOCK_SIZE = 32 * 1024 * 1024;
    const uint64_t n_ids = ds.getMemSpace().getDimensions()[0];
    const size_t n_blocks = n_ids / BLOCK_SIZE;
    const size_t remaining = n_ids % BLOCK_SIZE;

    ProgressBar pb(n_blocks + 1);

    NeuronIndex neuron_index;

    std::unique_ptr<index_type[]> buffer(new index_type[BLOCK_SIZE]);

    auto build_index = [&ds, &neuron_index, &buffer](const uint64_t offset,
                                                     const size_t length) {
        ds.select({offset}, {length}).read(buffer.get());
        neuron_index.index_ids(buffer.get(), length, offset);
    };

    uint64_t offset = dataset_offset;
    for (size_t i = 0; i < n_blocks; i++) {
        build_index(offset, BLOCK_SIZE);
        offset += BLOCK_SIZE;

        if (with_progress)
            pb.update(i);
    }

    if (remaining)
        build_index(offset, remaining);

    return neuron_index;
}

void NeuronIndex::write_secondary_index_to(HighFive::DataSet& dataset,
                                           uint64_t dataset_offset,
                                           bool with_progress) {
    size_t total_nrns = n_neurons();
    size_t neurons_prcessed = 0;
    ProgressBar pb(total_nrns);

    auto fwrite = [&](const NeuronIndex::neuron_ranges_t& range) {
        dataset.select({dataset_offset, 0}, {range.size(), 2}).write_raw(&range[0].first);
        dataset_offset += range.size();
        if (with_progress)
            pb.update(++neurons_prcessed);
    };

    foreach_neuron(fwrite);
}

const NeuronIndex::neuron_ranges_t& NeuronIndex::get_neuron_ranges(uint64_t id) {
    static neuron_ranges_t dummy;
    if (id >= data_.size()) {
        return dummy;
    }
    return data_.at(id);
}

void NeuronIndex::add_neuron_ranges(const uint64_t id, neuron_ranges_t&& ranges) {
    resize_if_needed(id);
    neuron_ranges_t& r = data_[id];

    if (r.empty()) {
        r = std::move(ranges);
    } else {
        r.reserve(r.size() + ranges.size());
        r.insert(r.end(), ranges.cbegin(), ranges.cend());
    }
}

void NeuronIndex::consolidate_ranges(neuron_ranges_t& ranges) {
    if (ranges.empty()) {
        return;
    }

    std::sort(ranges.begin(), ranges.end(), [](const auto& a, const auto& b) {
        return a.first < b.first || a.second < b.second;
    });

    size_t back = 0;
    for (size_t i = 1; i < ranges.size(); ++i) {
        if (ranges[back].second >= ranges[i].first) {
            ranges[back].second = std::max(ranges[back].second, ranges[i].second);
        } else {
            ++back;
            if (back != i) {
                ranges[back] = ranges[i];
            }
        }
    }
    ranges.resize(back + 1);
}
} // namespace syn2

////////////////////////////////////////////////////////////////////////////////
/// Helper functions directly at EDGE namespace
////////////////////////////////////////////////////////////////////////////////

namespace edge {

bool create_index(const HighFive::DataSet& values,
                  HighFive::Group& location,
                  const std::string& primary,
                  const std::string& secondary,
                  const bool with_progress,
                  const uint64_t count) {
    using namespace syn2;

    std::cout << "- Indexing "
              << values.getPath() << std::endl;

    if (location.exist(primary) && location.exist(secondary)) {
        std::cout << "- Index already present, skipping..." << std::endl;
        return true;
    } else if (location.exist(primary) || location.exist(secondary)) {
        std::cout << "- Index is corrupted, skipping..." << std::endl;
        return false;
    }

    NeuronIndex new_index = NeuronIndex::create_from_h5_dataset(values, with_progress);
    if (count > 0) {
        new_index.resize_if_needed(count - 1);
    }

    {
        matrix_index_raw raw_primary = new_index.compute_primary_index();

        HighFive::DataSet first_index = location.createDataSet<index_type>(
          primary, HighFive::DataSpace::From(raw_primary));
        first_index.write(raw_primary);
    }

    {
        std::cout << "- Writing indexes out to hdf5..." << std::endl;

        HighFive::DataSet second_index_ds = location.createDataSet<index_type>(
          secondary, HighFive::DataSpace({new_index.size(), 2}));
        new_index.write_secondary_index_to(second_index_ds, with_progress);
    }

    return true;
}

bool create_index_mpi(const HighFive::DataSet& values,
                      HighFive::Group& location,
                      const std::string& primary,
                      const std::string& secondary,
                      const bool with_progress,
                      const uint64_t count) {
    using namespace syn2;

#ifdef SYNTOOL_WITH_MPI
    mpi::mpi_comm comm;
    bool show_info = with_progress && comm.is_master();

    if (location.exist(primary) && location.exist(secondary)) {
        if (show_info) {
            std::cout << "- Index already present, skipping..." << std::endl;
        }
        return true;
    } else if (location.exist(primary) || location.exist(secondary)) {
        if (show_info) {
            std::cout << "- Index is corrupted, skipping..." << std::endl;
        }
        return false;
    }

    uint64_t dataset_len = values.getSpace().getDimensions()[0];

    uint64_t sel_len = dataset_len / comm.size();
    uint64_t remaining = dataset_len % comm.size();
    uint64_t sel_offset = sel_len * comm.rank();
    if ((uint32_t)comm.rank() < remaining) {
        sel_len++;
        sel_offset += comm.rank();
    } else {
        sel_offset += remaining;
    }

    // -- Start indexing in parallel --

    if (show_info) {
        std::cout << "- Indexing "
                  << values.getPath()
                  << " using " << comm.size() << " ranks..." << std::endl;
    }

    NeuronIndex sub_index = NeuronIndex::create_from_h5_dataset(
      values.select({sel_offset}, {sel_len}), sel_offset, show_info);

    // -- Collecting statistics --
    uint64_t total_nrns = std::max<uint64_t>(count, comm.all_max(sub_index.n_neurons()));
    uint64_t index_size = comm.all_sum(sub_index.size());

    // Setup destination datasets
    HighFive::DataSet first_index = location.createDataSet<index_type>(
      primary, HighFive::DataSpace({total_nrns, 2}));
    HighFive::DataSet second_index = location.createDataSet<index_type>(
      secondary, HighFive::DataSpace({index_size, 2}));

    // -- Collecting and writing indexes to HDF5

    if (show_info) {
        std::cout << "- Writing indexes out to hdf5..." << std::endl;
    }

    ProgressBar pb(total_nrns, show_info);
    WriteBuffer writer(first_index, second_index, WRITE_BLOCK_SIZE);

    for (uint64_t block_id = 0; block_id < total_nrns; block_id += GATHER_BLOCK_SIZE) {
        const uint64_t block_size = std::min(total_nrns - block_id, GATHER_BLOCK_SIZE);

        std::vector<uint32_t> local_range_sizes(block_size);
        NeuronIndex::neuron_ranges_t local_ranges;
        for (uint64_t j = 0; j < block_size; ++j) {
            const uint64_t id = block_id + j;
            const auto& id_ranges = sub_index.get_neuron_ranges(id);
            local_ranges.insert(local_ranges.end(), id_ranges.cbegin(), id_ranges.cend());
            local_range_sizes[j] = id_ranges.size();
        }

        std::vector<int32_t> global_range_sizes;
        std::vector<int> counts;
        std::vector<int> offsets;
        if (comm.is_master()) {
            global_range_sizes.resize(comm.size() * block_size);
            for (int i = 0; i < comm.size(); ++i) {
                counts.push_back(block_size);
                offsets.push_back(i * block_size);
            }
        }
        MPI_Gatherv(local_range_sizes.data(), block_size, MPI_INT32_T,
                    global_range_sizes.data(), counts.data(), offsets.data(),
                    MPI_INT32_T, 0, MPI_COMM_WORLD);

        NeuronIndex::neuron_ranges_t global_ranges;
        if (comm.is_master()) {
            const size_t total_count = std::accumulate(global_range_sizes.cbegin(), global_range_sizes.cend(), 0);
            global_ranges.resize(total_count);
            for (int i = 0; i < comm.size(); ++i) {
                counts[i] = 0;
                offsets[i] = 0;
                for (size_t j = 0; j < block_size; ++j) {
                    // factor of 2 as each range is a std::pair
                    counts[i] += global_range_sizes[i * block_size + j] * 2;
                }
                if (i > 0) {
                    offsets[i] = offsets[i - 1] + counts[i - 1];
                }
            }
        }
        MPI_Gatherv(local_ranges.data(), local_ranges.size() * 2, MPI_UINT64_T,
                    global_ranges.data(), counts.data(), offsets.data(),
                    MPI_UINT64_T, 0, MPI_COMM_WORLD);
        if (comm.is_master()) {
            std::vector<NeuronIndex::neuron_ranges_t> id_ranges(block_size);
            size_t idx = 0;
            for (size_t rank = 0; rank < comm.size(); ++rank) {
                for (uint64_t j = 0; j < block_size; ++j) {
                    const auto block_idx = rank * block_size + j;
                    for (uint32_t k = 0; k < global_range_sizes[block_idx]; ++k, ++idx) {
                        id_ranges[j].push_back(global_ranges[idx]);
                    }
                }
            }
            for (auto& ranges: id_ranges) {
                NeuronIndex::consolidate_ranges(ranges);
                writer.add(ranges);
            }

            if (show_info) {
                pb.update(block_id + block_size);
            }
        }
    }

    return true;
#else
    // Silence non-used vars
    (void)values, (void)location, (void)primary, (void)secondary, (void)with_progress,
      (void)count throw std::runtime_error("SYN2 was not compiled with support for MPI");
#endif // SYNTOOL_WITH_MPI
}
} // namespace edge
