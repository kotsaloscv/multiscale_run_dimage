/*
 * Copyright (C) 2017 Adrien Devresse <adrien.devresse@epfl.ch>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */

#include "syn2_common.hpp"
#include "translation.hpp"
#include <syn2/indexing.hpp>
#include <syn2/synapses_exceptions.hpp>
#include <syn2/synapses_writer.hpp>

#include <highfive/H5File.hpp>
#include <highfive/H5Version.hpp>

#include <functional>
#include <mutex>
#include <tuple>
#include <unordered_map>

#ifdef SYNTOOL_WITH_MPI
#include <mpi-cpp/mpi.hpp>
#include <mpi.h>
#endif

namespace syn2 {

static void create_version_attribute(HighFive::Group& g) {
    if (!g.hasAttribute("version")) {
        HighFive::Attribute a = g.createAttribute<std::int8_t>(
          "version", HighFive::DataSpace::From(version_file));
        a.write(version_file);
    }
}

static void create_group_if_not_exist(HighFive::File& file,
                                      const std::string& name,
                                      bool add_version_tag = false) {
    if (!file.exist(name)) {
        HighFive::Group new_group = file.createGroup(name);
        if (add_version_tag) {
            create_version_attribute(new_group);
        }
    }
}

struct property_writer::property_writer_internal {
    inline property_writer_internal(HighFive::DataSet&& d, const std::string& property_name)
          : _dataset(std::move(d))
          , _property_name(property_name) {}

    HighFive::DataSet _dataset;
    std::string _property_name;
};

struct synapses_writer::synapses_writer_internal {
    inline synapses_writer_internal(const std::string& filename, int flags)
          : _filename(filename)
          , _current_population(population::default_population())
          , _flags(flags)
          , _n_synapse(0)
          , _file(
              filename,
              HighFive::File::ReadWrite |
                ((flags & synapses_writer::create_flag) ? (HighFive::File::Create) : 0x00) |
                ((flags & synapses_writer::override_file_flag) ? (HighFive::File::Truncate)
                                                               : 0x00),
#ifdef SYNTOOL_WITH_MPI
              (flags & synapses_writer::use_mpi_flag)
                ? HighFive::MPIOFileDriver(MPI_COMM_WORLD, MPI_INFO_NULL)
                :
#endif
#if HIGHFIVE_VERSION_MAJOR >= 2 && HIGHFIVE_VERSION_MINOR >= 3
                HighFive::FileAccessProps::Default())
#else
                HighFive::FileDriver())
#endif
          , _lock()
          , _last_init_population() {
    }

    std::string _filename, _current_population;
    int _flags;
    std::uint64_t _n_synapse;

    // H5file
    HighFive::File _file;

    // initialization
    std::mutex _lock;
    std::string _last_init_population;

    inline void init_current_population() {
        std::lock_guard<std::mutex> l(_lock);

        if (_current_population != _last_init_population) {
            HighFive::File& h5 = _file;
            const std::string population_prefix = std::string(synapse_namespace) + "/" +
                                                  _current_population;

            create_group_if_not_exist(h5, synapse_namespace, true);
            create_group_if_not_exist(h5, population_prefix);
            create_group_if_not_exist(h5, population_prefix + "/" + property_namespace);
            create_group_if_not_exist(h5, population_prefix + "/" + index_namespace);
            _last_init_population = _current_population;
        }
    }

    template <typename ValueType>
    inline HighFive::DataSet get_dataset_for_property(const std::string& property,
                                                      const std::vector<std::size_t>& dims) {
        assert(dims.size() > 0);
        std::lock_guard<std::mutex> l(_lock);

        // setup the first dimension to total number of synapse
        std::vector<std::size_t> my_dims(dims.begin(), dims.end());
        my_dims[0] = _n_synapse;

        HighFive::DataSet new_property_dataset = _file.createDataSet<ValueType>(
          std::string(synapse_namespace) + "/" + _current_population + "/" +
            property_namespace + "/" + property,
          HighFive::DataSpace(my_dims));

        return new_property_dataset;
    }
};

class write_property_visitor : public boost::static_visitor<> {
public:
    write_property_visitor(HighFive::DataSet& dset, std::uint64_t offset)
          : _dset(dset)
          , _offset(offset) {}

    template <typename T>
    inline void operator()(const std::vector<T>& vec) {
        HighFive::Selection selection = _dset.select({_offset}, {vec.size()});
        selection.write(vec);
    }

    inline void operator()(const mat_double& mat) {
        HighFive::Selection selection = _dset.select({_offset, 0},
                                                     {mat.size1(), mat.size2()});
        selection.write(mat);
    }

private:
    HighFive::DataSet& _dset;
    std::uint64_t _offset;
};

property_writer::property_writer() {}

property_writer::~property_writer() {}

property_writer::property_writer(property_writer&& origin) {
    std::swap(origin._dptr, _dptr);
}

property_writer& property_writer::operator=(property_writer&& origin) {
    std::swap(origin._dptr, _dptr);
    return *this;
}

void property_writer::pwrite(const property_vec& data, uint64_t offset) {
    write_property_visitor writer(_dptr->_dataset, offset);
    boost::apply_visitor(writer, data);
}

std::string property_writer::property_name() const {
    return _dptr->_property_name;
}

synapses_writer::synapses_writer(const std::string& filename,
                                 int flags,
                                 synapse_file_format format)
      : _dptr(new synapses_writer_internal(filename, flags)) {
    if (format != synapse_file_format::syn2) {
        throw syn_exception(error_code::operation_not_supported,
                            "writing to other file format than syn2 is not currently "
                            "supported");
    }
}

synapses_writer::~synapses_writer() {}

synapses_writer::synapses_writer(synapses_writer&& origin) {
    std::swap(_dptr, origin._dptr);
}

synapses_writer& synapses_writer::operator=(synapses_writer&& origin) {
    std::swap(_dptr, origin._dptr);
    return *this;
}

void synapses_writer::resize(std::uint64_t number_synapses) {
    if (_dptr->_n_synapse != 0) {
        throw syn_exception(error_code::operation_not_supported,
                            "synapse layout can be resized only once");
    }
    _dptr->_n_synapse = number_synapses;
}

void synapses_writer::select_population(const std::string& population) {
    std::lock_guard<std::mutex> l(_dptr->_lock);
    _dptr->_current_population = population;
}

property_writer synapses_writer::open_or_create(const std::string& properties_name,
                                                const property_type& ptype,
                                                const std::vector<std::size_t>& dims) {
    property_writer w;
    _dptr->init_current_population();

    auto finstance = [&](HighFive::DataSet&& d) {
        w._dptr.reset(
          new property_writer::property_writer_internal(std::move(d), properties_name));
    };

    switch (ptype) {
        case property_type::vec_uint: {
            finstance(
              _dptr->get_dataset_for_property<vec_uint::value_type>(properties_name, dims));
            break;
        }
        case property_type::vec_int: {
            finstance(
              _dptr->get_dataset_for_property<vec_int::value_type>(properties_name, dims));
            break;
        }
        case property_type::vec_double: {
            finstance(_dptr->get_dataset_for_property<vec_double::value_type>(
              properties_name, dims));
            break;
        }
        case property_type::vec_byte: {
            finstance(
              _dptr->get_dataset_for_property<vec_byte::value_type>(properties_name, dims));
            break;
        }
        case property_type::mat_double: {
            finstance(_dptr->get_dataset_for_property<mat_double::value_type>(
              properties_name, dims));
            break;
        }
        default: {
            throw syn_exception(error_code::operation_not_supported,
                                std::string("Invalid property type ") +
                                  std::to_string(int(ptype)));
        }
    }

    return w;
}

void synapses_writer::create_all_index(const uint64_t neuron_count_pre,
                                       const uint64_t neuron_count_post) {
    _dptr->init_current_population();
    HighFive::Group current_group = _dptr->_file.getGroup(std::string(synapse_namespace) +
                                                          "/" + _dptr->_current_population);

    auto there = get_or_create(current_group, index_namespace,
                               property::connected_neurons_pre());
    auto back = get_or_create(current_group, index_namespace,
                              property::connected_neurons_post());

#ifdef SYNTOOL_WITH_MPI
    if (_dptr->_flags & synapses_writer::use_mpi_flag) {
        edge::create_index_mpi(current_group.getDataSet(std::string(property_namespace) +
                                                        "/" +
                                                        property::connected_neurons_pre()),
                               there, primary_neuron_namespace, secondary_neuron_namespace,
                               true, neuron_count_pre);
        edge::create_index_mpi(current_group.getDataSet(std::string(property_namespace) +
                                                        "/" +
                                                        property::connected_neurons_post()),
                               back, primary_neuron_namespace, secondary_neuron_namespace,
                               true, neuron_count_post);
        // Force return here so that create_neuron_index runs only as alternative
        return;
    }
#endif
    edge::create_index(current_group.getDataSet(std::string(property_namespace) + "/" +
                                                property::connected_neurons_pre()),
                       there, primary_neuron_namespace, secondary_neuron_namespace, true,
                       neuron_count_pre);
    edge::create_index(current_group.getDataSet(std::string(property_namespace) + "/" +
                                                property::connected_neurons_post()),
                       back, primary_neuron_namespace, secondary_neuron_namespace, true,
                       neuron_count_post);
}

void synapses_writer::compose_sonata(bool remove_syn2,
                                     const std::string& source,
                                     const std::string& target) {
    translation::Composer c(_dptr->_file, _dptr->_current_population);
    c.writeSONATA(remove_syn2, source, target);
}

} // namespace syn2
