/*
 * Copyright (C) 2017-2020 Blue Brain Project
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
#include "syn2/c_reader.h"
#include "syn2/synapses_properties.hpp"
#include "syn2/synapses_reader.hpp"

#include <cstring>
#include <iostream>
#include <memory>
#include <string>
#include <vector>

#include <highfive/H5Utility.hpp>


/// INTERNAL (hence static)

namespace SynReaders {

static syn2::options global_options;

static std::vector<std::unique_ptr<syn2::synapses_reader>> all_readers_;

static inline s2id_t create(const std::string& filename) {
    // This is not supposed to be multithreaded so we dont synchronize
    all_readers_.emplace_back(new syn2::synapses_reader(filename, global_options));
    return all_readers_.size() - 1;
}

static inline void destruct(s2id_t reader_id) {
    all_readers_[reader_id].reset(nullptr);
}

static inline syn2::synapses_reader* get(s2id_t reader_id) {
    return all_readers_[reader_id].get();
}

void log_exception(const std::exception& e) {
    if (SynReaders::global_options.is_verbose()) {
        std::cerr << "[Synapse reader] Exception: " << e.what() << std::endl;
    }
}

} // namespace SynReaders


static inline syn2::selection convert_selection(const Syn2Selection sel);


///////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////

void syn_set_verbose(int level) {
    SynReaders::global_options.verbose(level);
}
void syn_with_mpi() {
    SynReaders::global_options.with_mpi(true);
}


s2id_t syn_open(const char* filename) {
    try {
        return SynReaders::create(filename);
    } catch (const std::exception& e) {
        SynReaders::log_exception(e);
        return -1;
    }
}


void syn_close(const s2id_t syn_id) {
    SynReaders::destruct(syn_id);
}


size_t syn_get_number_synapses(const s2id_t syn_id) {
    return SynReaders::get(syn_id)->get_number_synapses();
}


Syn2Dataset syn_list_property_names(const s2id_t syn_id) {
    // The trick is to keep the return object alive so we can reuse
    // Users must make a copy if they require multiple results
    // We need to keep both alive, since the mem owner is res
    static std::vector<const char*> result_container(20);
    static std::vector<std::string> res;
    result_container.clear();
    res = SynReaders::get(syn_id)->list_property_names();

    for (const std::string& s : res) {
        result_container.push_back(s.c_str());
    }
    return {result_container.data(), result_container.size(), -1, SYN2_STR};
}


Syn2Dataset syn_list_populations(const s2id_t syn_id) {
    static std::vector<const char*> result_container(1);
    static std::vector<std::string> res;
    res = SynReaders::get(syn_id)->list_populations();
    result_container.clear();

    for (const std::string& s : res) {
        result_container.push_back(s.c_str());
    }
    return {result_container.data(), result_container.size(), -1, SYN2_STR};
}


int syn_select_population(const s2id_t syn_id, const char* population_name) {
    try {
        SynReaders::get(syn_id)->select_population(population_name);
    } catch (const std::exception& e) {
        SynReaders::log_exception(e);
        return -1;
    }
    return 0;
}


///////////////////////////////////////////////////////////////////////
/// Data retrieval
///////////////////////////////////////////////////////////////////////


class extract_data_visitor : public boost::static_visitor<const Syn2Dataset> {
public:
    Syn2Dataset operator()(const syn2::vec_double& vec) {
        return {vec.data(), vec.size(), 1, SYN2_DOUBLE};
    }
    Syn2Dataset operator()(const syn2::vec_int& vec) {
        return {vec.data(), vec.size(), 1, SYN2_INT};
    }
    Syn2Dataset operator()(const syn2::vec_uint& vec) {
        return {vec.data(), vec.size(), 1, SYN2_UINT};
    }
    Syn2Dataset operator()(const syn2::vec_byte& vec) {
        return {vec.data(), vec.size(), 1, SYN2_BYTE};
    }
    Syn2Dataset operator()(const syn2::mat_double& mat) {
        return {mat.data().begin(), mat.size1(), (int8_t)mat.size2(), SYN2_DOUBLE};
    }

    static extract_data_visitor& get() {
        static extract_data_visitor singleton_;
        return singleton_;
    }

private:
    extract_data_visitor() = default;
};


///////////////////////////////////////////////////////////////////////

Syn2Dataset syn_get_property(const s2id_t syn_id,
                             const char* property,
                             const Syn2Selection selection) {
    HighFive::SilenceHDF5 silencer;
    static syn2::property_vec re;

    // get_property succeeds with count zero if post cell dataset doesnt exist
    // but throws exception if field (property) doesnt exist
    re = SynReaders::get(syn_id)->get_property(property, convert_selection(selection));

    return re.apply_visitor(extract_data_visitor::get());
}


///////////////////////////////////////////////////////////////////////

Syn2Table syn_get_property_table(const s2id_t syn_id,
                                 const char* properties,
                                 const Syn2Selection selection) {
    HighFive::SilenceHDF5 silencer;
    static const int TYPICAL_N_COLS = 12;
    static std::vector<syn2::property_vec> data(TYPICAL_N_COLS);
    static std::vector<Syn2Field> fields(TYPICAL_N_COLS);
    data.clear();
    fields.clear();
    syn2::synapses_reader* reader = SynReaders::get(syn_id);
    std::string cp(properties);
    char* prop = std::strtok(const_cast<char*>(cp.c_str()), " ,");
    uint32_t record_count = 0;

    while (prop) {
        data.push_back(reader->get_property(prop, convert_selection(selection)));
        prop = std::strtok(NULL, " ,");
    }

    // Only after all data has been inserted we can get the pointers.
    // Before that, realocation might occur
    for (auto& syn2data : data) {
        Syn2Dataset ds = syn2data.apply_visitor(extract_data_visitor::get());
        fields.push_back({ds.data, ds.columns, ds.datatype});
        record_count = ds.length;
    }

    return {fields.data(), record_count, (int8_t)fields.size(), SYN2_TABLE};
}


///////////////////////////////////////////////////////////////////////
/// Selections
///////////////////////////////////////////////////////////////////////

inline syn2::selection convert_selection(const Syn2Selection sel) {
    switch (sel.selection_mode) {
        case SYN_SELECTION::SYN2_SEL_ALL:
            return syn2::selection::all();
        case SYN_SELECTION::SYN2_SEL_FILTER_PRE:
            return syn2::selection::by_pre_neuron_id(sel.pre_gid);
        case SYN_SELECTION::SYN2_SEL_FILTER_POST:
            return syn2::selection::by_post_neuron_id(sel.post_gid);
        case SYN_SELECTION::SYN2_SEL_FILTER_PRE_POST:
            return syn2::selection::by_post_neuron_id(sel.post_gid);
    }
    return syn2::selection::all();
}

Syn2Selection syn_select_all() {
    return {0, 0, SYN2_SEL_ALL};
}
Syn2Selection syn_select_pre(uint32_t pre_gid) {
    return {pre_gid, 0, SYN2_SEL_FILTER_PRE};
}
Syn2Selection syn_select_post(uint32_t post_gid) {
    return {0, post_gid, SYN2_SEL_FILTER_POST};
}
Syn2Selection syn2_select_pre_post(uint32_t pre_gid, uint32_t post_gid) {
    return {pre_gid, post_gid, SYN2_SEL_FILTER_PRE_POST};
}


/////////////////////////////////////////////////////////////////////////
/// Copying
/////////////////////////////////////////////////////////////////////////


Syn2Dataset syn2_copy_dataset(Syn2Dataset ds) {
    size_t size = syn2_sizeof(ds.datatype) * ds.length * ds.columns;
    void* buf = malloc(size);
    memcpy(buf, ds.data, size);
    return {buf, ds.length, ds.columns, ds.datatype};
}


Syn2Table syn2_copy_table(Syn2Table table) {
    // Two levels of indirection
    // 1. we replicate the indexes
    size_t idx_size = sizeof(Syn2Field) * table.n_fields;
    Syn2Field* new_idx = static_cast<Syn2Field*>(malloc(idx_size));
    memcpy(new_idx, table.fields, idx_size);

    // 2. Copy data and update index
    for (int i = 0; i < table.n_fields; i++) {
        Syn2Field& f = new_idx[i];
        size_t rec_size = syn2_sizeof(f.datatype) * f.columns * table.length;
        void* new_data = malloc(rec_size);
        memcpy(new_data, f.data, rec_size);
        f.data = new_data;
    }

    table.fields = new_idx;
    return table;
}


void syn2_free(void* dataset) {
    const Syn2Dataset* info = static_cast<const Syn2Dataset*>(dataset);

    // Syn2Table requires freeing indirect data first
    if (info->datatype == SYN2_TABLE) {
        const Syn2Field* fields = static_cast<const Syn2Field*>(info->data);
        for (int i = 0; i < info->columns; i++) {
            free(const_cast<void*>(fields[i].data));
        }
    }
    free(const_cast<void*>(info->data));
}
