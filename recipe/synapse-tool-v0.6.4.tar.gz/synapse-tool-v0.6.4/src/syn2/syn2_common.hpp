/*
 * Copyright (C) 2017 Adrien Devresse <adrien.devresse@epfl.ch>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
#pragma once

#include <syn2/synapses_properties.hpp>
#include <syn2/synapses_selection.hpp>

#include <boost/variant.hpp>

#include <cstdint>
#include <mutex>
#include <vector>


namespace syn2 {

// namespace
const char synapse_namespace[] = "/synapses";

const char property_namespace[] = "properties";

const char index_namespace[] = "indexes";

// index names
const char primary_neuron_namespace[] = "neuron_id_to_range";

const char secondary_neuron_namespace[] = "range_to_synapse_id";


extern std::vector<std::int8_t> version_file;


//
// hdf5 related lock
//
std::mutex& hdf5_lock();

//
// Interface for the implementation of the synapse reeader
//
class synapses_reader_interface {
public:
    virtual ~synapses_reader_interface();

    virtual std::size_t get_number_synapses() = 0;


    virtual property_vec get_property(const std::string& property,
                                      const selection& slice) = 0;


    virtual std::vector<std::string> list_property_names(bool include_virtual = true) = 0;

    virtual std::vector<std::string> list_populations() = 0;

    virtual void select_population(const std::string& population_name) = 0;
};


//
// virtual properties
//

vec_uint retrieve_synapse_index(const multirange_synapse& ranges);


} // namespace syn2
