/*
 * Copyright (C) 2017-2020 Blue Brain Project
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
#include "translation.hpp"

#include <highfive/H5File.hpp>

#include <set>


namespace syn2 {
namespace translation {

template <std::size_t s, std::size_t t>
void translate(HighFive::File& file, const std::string& population, bool rename) {
    using namespace std::placeholders;

    static const Naming naming;

    const auto& top_source = std::get<s>(naming.toplevel).c_str();
    const auto& top_target = std::get<t>(naming.toplevel).c_str();

    auto source = file.getGroup(top_source).getGroup(population);
    auto target = source;

    if (rename) {
        H5Lmove(file.getId(), top_source, file.getId(), top_target, H5P_DEFAULT,
                H5P_DEFAULT);
    } else {
        target = file.createGroup(top_target).createGroup(population);
    }

    const auto source_indices = std::get<s>(naming.indexing);
    const auto target_indices = std::get<t>(naming.indexing);

    const auto source_properties = std::get<s>(naming.properties);
    const auto target_properties = std::get<t>(naming.properties);

    target.createGroup(target_properties);
    for (const auto& g : target_indices) {
        target.createGroup(g);
    }

    auto relink = [&](const std::string& from, const std::string& to) {
        if (rename) {
            H5Lmove(source.getId(), from.c_str(), target.getId(), to.c_str(), H5P_DEFAULT,
                    H5P_DEFAULT);
        } else {
            H5Lcreate_hard(source.getId(), from.c_str(), target.getId(), to.c_str(),
                           H5P_DEFAULT, H5P_DEFAULT);
        }
    };
    auto unlink = [&](const std::string& name) {
        HighFive::SilenceHDF5 silencer;
        try {
            if (source.exist(name)) {
                H5Ldelete(source.getId(), name.c_str(), H5P_DEFAULT);
            }
        } catch (const HighFive::GroupException&) {
            // One of the parent groups may already have been deleted
        }
    };

    std::set<std::string> found;
    for (const auto& tpl : naming.datasets) {
        const auto from = std::get<s>(tpl);
        const auto to = std::get<t>(tpl);
        if (source.exist(from)) {
            relink(from, to);
            found.emplace(from);
        }
    }
    for (const auto& name : source.getGroup(source_properties).listObjectNames()) {
        const auto from = source_properties + "/" + name;
        const auto to = target_properties + "/" + name;
        if (found.find(from) == found.end()) {
            relink(from, to);
        }
    }

    if (rename) {
        if (source_properties != target_properties) {
            unlink(source_properties);
        }
        for (const auto& name : source_indices) {
            if (std::find(target_indices.begin(), target_indices.end(), name) ==
                target_indices.end()) {
                unlink(name);
            }
        }
    }
}

void Composer::writeSONATA(bool rename,
                           const std::string& source,
                           const std::string& target) {
    const std::size_t syn2_i = static_cast<std::size_t>(synapse_file_format::syn2);
    const std::size_t sonata_i = static_cast<std::size_t>(synapse_file_format::sonata);
    const Naming naming;

    translate<syn2_i, sonata_i>(file_, population_, rename);
    file_.getGroup(std::get<sonata_i>(naming.toplevel))
      .getGroup(population_)
      .getDataSet("source_node_id")
      .createAttribute("node_population", source);
    file_.getGroup(std::get<sonata_i>(naming.toplevel))
      .getGroup(population_)
      .getDataSet("target_node_id")
      .createAttribute("node_population", target);
}

Naming::t_ Naming::get_toplevel() {
    return {"synapses", "edges"};
}

Naming::t_ Naming::get_properties() {
    return {"properties", "0"};
}

Naming::v_ Naming::get_indexing() {
    return {{"indexes", "indexes/connected_neurons_pre", "indexes/connected_neurons_post"},
            {"indices", "indices/source_to_target", "indices/target_to_source"}};
}

std::vector<Naming::t_> Naming::get_datasets() {
    return {{"indexes/connected_neurons_pre/neuron_id_to_range",
             "indices/source_to_target/node_id_to_ranges"},
            {"indexes/connected_neurons_pre/range_to_synapse_id",
             "indices/source_to_target/range_to_edge_id"},
            {"indexes/connected_neurons_post/neuron_id_to_range",
             "indices/target_to_source/node_id_to_ranges"},
            {"indexes/connected_neurons_post/range_to_synapse_id",
             "indices/target_to_source/range_to_edge_id"},
            {"properties/connected_neurons_pre", "source_node_id"},
            {"properties/connected_neurons_post", "target_node_id"},
            {"properties/synapse_type_id", "edge_type_id"},
            {"properties/morpho_section_id_pre", "0/efferent_section_id"},
            {"properties/morpho_section_id_post", "0/afferent_section_id"},
            {"properties/morpho_section_fraction_pre", "0/efferent_section_pos"},
            {"properties/morpho_section_fraction_post", "0/afferent_section_pos"},
            {"properties/morpho_segment_id_pre", "0/efferent_segment_id"},
            {"properties/morpho_segment_id_post", "0/afferent_segment_id"},
            {"properties/morpho_offset_segment_pre", "0/efferent_segment_offset"},
            {"properties/morpho_offset_segment_post", "0/afferent_segment_offset"},
            {"properties/morpho_section_type_pre", "0/efferent_section_type"},
            {"properties/morpho_section_type_post", "0/afferent_section_type"},
            {"properties/morpho_spine_length", "0/spine_length"},
            {"properties/morpho_type_id_pre", "0/efferent_morphology_id"},
            {"properties/position_center_post_x", "0/afferent_center_x"},
            {"properties/position_center_post_y", "0/afferent_center_y"},
            {"properties/position_center_post_z", "0/afferent_center_z"},
            {"properties/position_contour_post_x", "0/afferent_surface_x"},
            {"properties/position_contour_post_y", "0/afferent_surface_y"},
            {"properties/position_contour_post_z", "0/afferent_surface_z"},
            {"properties/position_center_pre_x", "0/efferent_center_x"},
            {"properties/position_center_pre_y", "0/efferent_center_y"},
            {"properties/position_center_pre_z", "0/efferent_center_z"},
            {"properties/position_contour_pre_x", "0/efferent_surface_x"},
            {"properties/position_contour_pre_y", "0/efferent_surface_y"},
            {"properties/position_contour_pre_z", "0/efferent_surface_z"}};
}

} // namespace translation
} // namespace syn2
