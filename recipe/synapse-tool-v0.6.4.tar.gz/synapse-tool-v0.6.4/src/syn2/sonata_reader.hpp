/*
 * Copyright (C) 2018 Blue Brain Project
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
#pragma once

#include "syn2_common.hpp"
#include <bbp/sonata/edges.h>
#include <syn2/synapses_reader.hpp>
#include <syn2/synapses_selection.hpp>

#include <map>
#include <mutex>


namespace syn2 {

class sonata_reader : public synapses_reader_interface {
public:
    sonata_reader(const std::string& filename, const options& opt);
    virtual ~sonata_reader();

    std::size_t get_number_synapses() override;

    property_vec get_property(const std::string& property, const selection& slice) override;

    std::vector<std::string> list_property_names(bool include_virtual = true) override;

    std::vector<std::string> list_populations() override;

    void select_population(const std::string& population_name) override;

private:
    bbp::sonata::Selection _resolve_selection(const selection& slice) const;
    std::string _resolve_property(const std::string& property) const;

    std::unique_ptr<bbp::sonata::EdgeStorage> _storage;

    // NB: we re-use hdf5_lock() context to ensure exclusive access to `_population`
    std::shared_ptr<bbp::sonata::EdgePopulation> _population;

    // Translation of property names
    const std::map<std::string, std::string> _to_sonata;
    const std::map<std::string, std::string> _from_sonata;

    const int _verbose;
};


} // namespace syn2
