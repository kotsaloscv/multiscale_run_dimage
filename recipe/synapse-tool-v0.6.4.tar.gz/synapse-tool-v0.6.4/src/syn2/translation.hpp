/*
 * Copyright (C) 2017-2020 Blue Brain Project
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
#pragma once

#include <syn2/synapses_writer.hpp>

#include <highfive/H5File.hpp>

#include <map>
#include <vector>


namespace syn2 {
namespace translation {

// Container to hold naming schemes.
//
// Assuming that the general structure is of files within HDF5 is the same,
// this provides tuples of namings, where each index corresponds to one
// naminng scheme.
class Naming {
public:
    using t_ = std::tuple<std::string, std::string>;
    using v_ = std::tuple<std::vector<std::string>, std::vector<std::string>>;

    // These fields have to have the same order as the indices in enum
    // class synapse_file_format
    const t_ toplevel;
    const t_ properties;
    const v_ indexing;
    const std::vector<t_> datasets;

    Naming()
          : toplevel(get_toplevel())
          , properties(get_properties())
          , indexing(get_indexing())
          , datasets(get_datasets()){};

    template <int s, int t>
    inline static std::map<std::string, std::string> get_property_mapping() {
        std::map<std::string, std::string> mapping;

        const auto from = std::get<s>(get_properties()) + "/";
        const auto to = std::get<t>(get_properties()) + "/";

        for (const auto& tpl : get_datasets()) {
            const auto source = std::get<s>(tpl);
            const auto target = std::get<t>(tpl);

            if (source.find(from) == 0 and target.find(to) == 0) {
                mapping.emplace(source.substr(from.size()), target.substr(to.size()));
            }
        }
        return mapping;
    }

private:
    static t_ get_toplevel();
    static t_ get_properties();
    static v_ get_indexing();
    static std::vector<t_> get_datasets();
};

class Composer {
public:
    Composer(HighFive::File& file, const std::string& population_name)
          : file_(file)
          , population_(population_name) {}

    /** Write SONATA datasets to the file
     *
     * \param rename If true, rename the datasets in the file, otherwise
     * just create links between Syn2 and SONATA.
     * \param source The name of the node source population
     * \param target The name of the node target population
     */
    void writeSONATA(bool rename, const std::string& source, const std::string& target);

private:
    HighFive::File file_;
    const std::string population_;
};

} // namespace translation
} // namespace syn2
