/*
 * Copyright (C) 2017 Adrien Devresse <adrien.devresse@epfl.ch>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
#include "syn2_reader.hpp"
#include "syn2_common.hpp"
#include <syn2/synapses_exceptions.hpp>

#include <array>


namespace syn2 {

typedef boost::numeric::ublas::matrix<std::uint64_t> matrix_index_raw;

struct read_operation_params {
    inline read_operation_params()
          : ranges()
          , full(false) {}

    multirange_synapse ranges;
    bool full;
};


struct syn2_reader::index_neuron {
    inline index_neuron(const HighFive::DataSet& my_primary,
                        const HighFive::DataSet& my_secondary)
          : primary(my_primary)
          , secondary(my_secondary) {}

    HighFive::DataSet primary, secondary;
};

syn2_reader::syn2_reader(const std::string& filename, const options& opts)
      : _filename(filename)
      , _population(population::default_population())
      , _file()
      , _verbose(opts.is_verbose())
      , _index_neuron_pre(nullptr)
      , _index_neuron_post(nullptr) {
    {
        std::lock_guard<std::mutex> _l(hdf5_lock());
        _file.reset(new HighFive::File(filename));
    }
}

syn2_reader::~syn2_reader() {}

void check_consistent_index(matrix_index_raw& index, const std::string& index_type) {
    // check if consistent
    if (index.size1() < 1 && index.size2() != 2) {
        throw syn_exception(error_code::invalid_layout,
                            std::string("Inconsistent index ") + index_type + " layout");
    }

    for (std::size_t i = 0; i < index.size1(); ++i) {
        if (index(i, 0) > index(i, 1)) {
            throw syn_exception(error_code::invalid_layout,
                                std::string("Inconsistent index ") + index_type + " " +
                                  std::to_string(index(i, 0)) + " " +
                                  std::to_string(index(i, 1)));
        }
    }
}

multirange_synapse resolve_neuron_index(syn2_reader::index_neuron& index,
                                        std::uint64_t id) {
    multirange_synapse all_ranges;
    matrix_index_raw range_primary, range_secondary;

    if (id >= index.primary.getSpace().getDimensions()[0]) {
        // not in the index range, return empty selection
        return multirange_synapse();
    }

    // read primary index and fetch
    // the position + number of ranges
    index.primary.select({id, 0}, {1, 2}).read(range_primary);
    check_consistent_index(range_primary, "primary");

    const std::uint64_t range_primary_begin = range_primary(0, 0);
    const std::uint64_t range_primary_end = range_primary(0, 1);

    // same id = no ranges
    if (range_primary_begin == range_primary_end) {
        return multirange_synapse();
    }

    index.secondary
      .select({range_primary_begin, 0}, {range_primary_end - range_primary_begin, 2})
      .read(range_secondary);
    check_consistent_index(range_secondary, "secondary");

    // vector of array -> best resize then direct assign values
    all_ranges.resize(range_secondary.size1());

    for (auto i = 0ul; i < range_secondary.size1(); ++i) {
        all_ranges[i] = {range_secondary(i, 0), range_secondary(i, 1)};
    }
    return all_ranges;
}


// resolve a selection if any
// return false if select all
void syn2_reader::resolve_selection(const selection& s,
                                    multirange_synapse& ranges,
                                    bool& full) {
    full = false;

    auto all_ranges = s.all_synapse_ranges();
    if (!all_ranges.empty()) {
        ranges.swap(all_ranges);
        return;
    }

    auto post_ids = s.post_synaptic_ids();
    if (post_ids.size() > 0) {
        open_indexes();
        if (!_index_neuron_post) {
            throw syn_exception(error_code::invalid_layout,
                                "Cannot select synapses by post neuron GID without "
                                "indexes, please create indexes");
        }

        multirange_synapse post_ranges = resolve_neuron_index(*_index_neuron_post,
                                                              post_ids[0]);
        ranges.swap(post_ranges);
        return;
    }

    auto pre_ids = s.pre_synaptic_ids();
    if (pre_ids.size() > 0) {
        open_indexes();
        if (!_index_neuron_pre) {
            throw syn_exception(error_code::invalid_layout,
                                "Cannot select synapses by pre neuron GID without indexes, "
                                "please create indexes");
        }

        multirange_synapse pre_ranges = resolve_neuron_index(*_index_neuron_pre,
                                                             pre_ids[0]);
        ranges.swap(pre_ranges);
        return;
    }

    full = true;
}


void syn2_reader::open_indexes() {
    // Keep open indexes in memory if they exist
    const std::string group_index = std::string(synapse_namespace) + "/" + _population +
                                    "/" + index_namespace;

    if (!_index_neuron_post) {
        const std::string group_post = group_index + "/" +
                                       property::connected_neurons_post();
        if (_file->exist(group_post)) {
            _index_neuron_post.reset(new syn2_reader::index_neuron(
              _file->getDataSet(group_post + "/" + primary_neuron_namespace),
              _file->getDataSet(group_post + "/" + secondary_neuron_namespace)));
        }
    }

    if (!_index_neuron_pre) {
        const std::string group_pre = group_index + "/" + property::connected_neurons_pre();
        if (_file->exist(group_pre)) {
            _index_neuron_pre.reset(new syn2_reader::index_neuron(
              _file->getDataSet(group_pre + "/" + primary_neuron_namespace),
              _file->getDataSet(group_pre + "/" + secondary_neuron_namespace)));
        }
    }
}

std::size_t syn2_reader::get_number_synapses() {
    std::lock_guard<std::mutex> _l(hdf5_lock());

    HighFive::DataSet pre_dataset = _file->getDataSet(std::string(synapse_namespace) + "/" +
                                                      _population +
                                                      "/" +
                                                      property_namespace +
                                                      "/" +
                                                      property::connected_neurons_pre());

    auto vec_dim = pre_dataset.getSpace().getDimensions();
    if (vec_dim.size() != 1) {
        throw syn_exception(error_code::invalid_layout,
                            std::string("Invalid file format : dataset ") +
                              property::connected_neurons_pre() +
                              " should be of dimension 1");
    }

    return vec_dim[0];
}


std::vector<std::string> syn2_reader::list_property_names(bool include_virtual) {
    std::vector<std::string> properties;
    std::lock_guard<std::mutex> _l(hdf5_lock());

    HighFive::Group property_group = _file->getGroup(std::string(synapse_namespace) + "/" +
                                                     _population + "/" + property_namespace);
    properties = property_group.listObjectNames();

    if (include_virtual) {
        // Append virtual properties
        properties.push_back(property::synapse_index());
    }

    return properties;
}


std::vector<std::string> syn2_reader::list_populations() {
    std::lock_guard<std::mutex> _l(hdf5_lock());

    HighFive::Group property_group = _file->getGroup(std::string(synapse_namespace) + "/");

    return property_group.listObjectNames();
}


void syn2_reader::select_population(const std::string& population_name) {
    std::lock_guard<std::mutex> _l(hdf5_lock());
    _population = population_name;
}


template <typename T>
T read_dataset_anytype(HighFive::DataSet& dset,
                       const std::vector<std::size_t>& dims,
                       const struct read_operation_params& params) {
    T ret;

    const multirange_synapse& ranges = params.ranges;

    if (params.full == true) { // full read
        dset.read(ret);
    } else if (ranges.size() == 1) { // single sub-select
        const range_synapse& first_range = ranges.front();
        const std::size_t offset = std::get<0>(first_range);
        const std::size_t count = std::get<1>(first_range) - offset;


        if (dims.size() == 1) {
            dset.select({offset}, {count}).read(ret);
        } else {
            dset.select({offset, 0}, {count, dims[1]}).read(ret);
        }
    } else if (ranges.size() > 1) {
        // execute an element by element subselect for multi range now
        // sub-optimal but easy to do for now

        std::vector<std::size_t> ids;
        ids.reserve(ranges.size() * 2);
        for (const range_synapse& range : ranges) {
            for (auto line = range[0]; line < range[1]; ++line) {
                ids.emplace_back(line);
                // if dimensions > 1 add 0 as other dimension points
                for (auto other_dim_line = 1ul; other_dim_line < dims.size();
                     ++other_dim_line) {
                    ids.push_back(0);
                }
            }
        }
        dset.select(HighFive::ElementSet(ids)).read(ret);
    }
    return ret;
}


property_vec read_property_any_type(HighFive::DataSet& dset,
                                    const std::string& dataset_path,
                                    const struct read_operation_params& params) {
    HighFive::DataType dset_type = dset.getDataType();
    std::vector<std::size_t> dims = dset.getMemSpace().getDimensions();

    if (dset_type == HighFive::AtomicType<std::uint64_t>() && dims.size() == 1) {
        return property_vec(read_dataset_anytype<vec_uint>(dset, dims, params));
    }
    if (dset_type == HighFive::AtomicType<std::int64_t>() && dims.size() == 1) {
        return property_vec(read_dataset_anytype<vec_int>(dset, dims, params));
    }
    if (dset_type == HighFive::AtomicType<std::uint32_t>() && dims.size() == 1) {
        return property_vec(read_dataset_anytype<vec_uint>(dset, dims, params));
    }
    if (dset_type == HighFive::AtomicType<std::int32_t>() && dims.size() == 1) {
        return property_vec(read_dataset_anytype<vec_int>(dset, dims, params));
    }
    if (dset_type == HighFive::AtomicType<float>() && dims.size() == 1) {
        return property_vec(read_dataset_anytype<vec_double>(dset, dims, params));
    }
    if (dset_type == HighFive::AtomicType<double>() && dims.size() == 1) {
        return property_vec(read_dataset_anytype<vec_double>(dset, dims, params));
    }
    if (dset_type == HighFive::AtomicType<double>() && dims.size() == 2) {
        return property_vec(read_dataset_anytype<mat_double>(dset, dims, params));
    }
    if (dset_type == HighFive::AtomicType<std::uint16_t>() && dims.size() == 1) {
        return property_vec(read_dataset_anytype<vec_uint>(dset, dims, params));
    }
    if (dset_type == HighFive::AtomicType<std::int16_t>() && dims.size() == 1) {
        return property_vec(read_dataset_anytype<vec_int>(dset, dims, params));
    }
    if (dset_type == HighFive::AtomicType<std::uint8_t>() && dims.size() == 1) {
        return property_vec(read_dataset_anytype<vec_byte>(dset, dims, params));
    }
    if (dset_type == HighFive::AtomicType<std::int8_t>() && dims.size() == 1) {
        return property_vec(read_dataset_anytype<vec_byte>(dset, dims, params));
    }

    throw syn_exception(error_code::invalid_data_type,
                        std::string("Invalid datatype / dimensions for dataset ") +
                          dataset_path +
                          " datatype_id=" + std::to_string(dset_type.getId()) +
                          " dimension=" + std::to_string(dims.size()));
}


property_vec syn2_reader::get_property(const std::string& prop, const selection& slice) {
    static const auto& props = list_property_names();
    std::lock_guard<std::mutex> _l(hdf5_lock());

    struct read_operation_params params;
    resolve_selection(slice, params.ranges, params.full);

    // Virtual properties
    if (prop == property::synapse_index()) {
        return retrieve_synapse_index(params.ranges);
    }

    // Property exists?
    if (std::find(props.cbegin(), props.cend(), prop) == props.cend()) {
        throw syn_exception(error_code::property_not_existing,
                            std::string("Property doesn't exist: ") + prop);
    }

    const std::string property_path = std::string(synapse_namespace) + "/" + _population +
                                      "/" + property_namespace + "/" + prop;

    HighFive::DataSet data = _file->getDataSet(property_path);

    return read_property_any_type(data, property_path, params);
}


} // namespace syn2
