/*
 * Copyright (C) 2017 Adrien Devresse <adrien.devresse@epfl.ch>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
#ifndef NRN_READER_HPP
#define NRN_READER_HPP

#include "syn2_common.hpp"
#include <syn2/synapses_reader.hpp>
#include <syn2/synapses_selection.hpp>

#include <highfive/H5File.hpp>

#include <functional>
#include <mutex>
#include <string>
#include <unordered_map>


// NRN v2017 = 19 fields, inc NRRP, post/pre-segment /offset
// Doesnt contain some syn2 spec properties, e.g. section_distance
#define NRN_VERSION 2017

namespace syn2 {

namespace nrn_specific_property {

const std::string morpho_segment_id_post();
const std::string morpho_segment_id_pre();
const std::string morpho_offset_segment_post();
const std::string morpho_offset_segment_pre();
const std::string morpho_type_id_pre();
const std::string morpho_branch_order_dend();
const std::string morpho_branch_order_axon();
const std::string n_rrp_vesicles();
const std::string morpho_section_type_post();
const std::string nrn_line();

} // namespace nrn_specific_property


class nrn_reader : public synapses_reader_interface {
public:
    typedef boost::numeric::ublas::matrix<float> raw_data_mat;

    nrn_reader(const std::string& directory, const options& opt);

    std::size_t get_number_synapses() override;
    std::size_t get_number_synapses_post_id(std::size_t id_post);

    property_vec get_property(const std::string& property, const selection& slice) override;

    std::vector<std::string> list_property_names(bool include_virtual = true) override;

    std::vector<std::string> list_populations() override;

    void select_population(const std::string& population_name) override;

    const std::vector<std::size_t>& get_all_ids_pre();

private:
    typedef std::function<property_vec(const std::size_t id_pre, const selection&)>
      get_property_fun;

    nrn_reader(const nrn_reader&) = delete;
    nrn_reader& operator=(const nrn_reader&) = delete;

    // internal data
    std::string _dirname;
    std::size_t _number_synapse;
    std::vector<std::size_t> _all_neuron_ids;
    int _verbose;

    std::unique_ptr<HighFive::File> _nrn_file, _nrn_position_file;
    std::once_flag _init_count;
    std::unordered_map<std::string, get_property_fun> _property_mapper;

    struct LoadedDataset {
        size_t tgid;
        raw_data_mat data;
    } _cur_dataset;

    // Cache the last offset to avoid recursing all the way down
    // Enough to have perfect cache hit in case query is gid ascending (most common)
    std::pair<std::size_t, std::size_t> _synapse_offset_cache;

    void init_metadata();

    get_property_fun& resolve_property_fun(const std::string& property);

    property_vec get_single_property_post(const std::string& property, std::uint64_t id);

    property_vec get_all_property(const std::string& property);

    raw_data_mat& get_data_for_post_id(std::size_t id);

    std::size_t get_synapse_offset_post_id(std::size_t id, bool cache = true);
};


} // namespace syn2

#endif // NRN_READER_HPP
