/*
 * Copyright (C) 2017-2020 Blue Brain Project
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */
#pragma once

#include <highfive/H5File.hpp>

#include <vector>

namespace syn2 {

typedef uint64_t index_type;
typedef boost::numeric::ublas::matrix<index_type> matrix_index_raw;

class NeuronIndex {
public:
    typedef std::vector<std::pair<index_type, index_type>> neuron_ranges_t;
    typedef std::vector<neuron_ranges_t> neuron_index;

    NeuronIndex()
          : length_(0) {}

    /**
     * @brief index_ids - Indexes an (additional) set of ids
     * @param raw_ids - The raw ids (plain array)
     * @param length - The length of the raw array
     * @param offset - The offset of the array data within a global ids dataset
     */
    void index_ids(const index_type* raw_ids, uint64_t length, const uint64_t offset = 0);

    /**
     * @brief index_ids - Indexes an (additional) set of ids
     * @param ids - The vector of ids
     * @param offset - The offset of the vector data within a global ids dataset
     */
    void index_ids(std::vector<index_type> ids, const uint64_t offset = 0);

    /**
     * @brief compute_primary_index - Computes the primary index into an index
     * matrix structure
     */
    matrix_index_raw compute_primary_index();

    /**
     * @brief compute_secondary_index - Computes the secondary index into an index
     * matrix structure
     *        NOTE: This function shall be avoided with large datasets since it
     * duplicates memory usage.
     */
    matrix_index_raw compute_secondary_index();

    /**
     * @brief create_from_h5_dataset - Indexes a H5 dataset for SYN2
     * @param ds - The dataset to be indexed. If it is a partial dataset user may
     * define the row offset
     * @param dataset_offset - The offset of ds relativelly to the global dataset
     */
    template <class T>
    static NeuronIndex create_from_h5_dataset(const T& ds,
                                              uint64_t dataset_offset = 0,
                                              bool with_progress = true);

    template <class T>
    inline static NeuronIndex create_from_h5_dataset(const T& ds,
                                                     bool with_progress = true) {
        return NeuronIndex::create_from_h5_dataset(ds, 0, with_progress);
    }

    /**
     * @brief write_secondary_index_to
     *        Writes the secondary index to a HighFive selection.
     * @param dataset: The destination dataset selection.
     * @param dataset_offset: Start writing index at a given dest position,
     * eventually used for a distributed write.
     */
    void write_secondary_index_to(HighFive::DataSet& dataset,
                                  uint64_t dataset_offset = 0,
                                  bool with_progress = true);

    inline void write_secondary_index_to(HighFive::DataSet& dataset,
                                         bool with_progress = true) {
        write_secondary_index_to(dataset, 0, with_progress);
    }

    ////////////////////////////////////////////
    /// Accessor / visitor functions
    ////////////////////////////////////////////

    template <class T>
    inline void foreach_neuron(T f) {
        for (auto& group : data_) {
            f(group);
        }
    }

    inline uint64_t size() {
        return length_;
    }

    inline size_t n_neurons() {
        return data_.size();
    }

    // This is sligtly lower level API - should be protected and be friends with
    // NeuronWriter

    /// @returns The index ranges associate with a single neuron.
    /// NOTE: If the id is invalid or not found it returns an empty vector
    const neuron_ranges_t& get_neuron_ranges(uint64_t id);

    /**
     * @brief add_neuron_ranges - The ranges of neurons to add to the current
     * index
     * @param id - The neuron id the ranges belong to
     * @param ranges - Index ranges to be appended
     * NOTE: If the current set is empty ranges memory is reused
     */
    void add_neuron_ranges(const uint64_t id, neuron_ranges_t&& ranges);

    /**
     * @brief Consolidate neuron ranges and shrink sub_index accordingly
     * @param ranges - Index ranges to be consolidated (in place)
     */
    static void consolidate_ranges(neuron_ranges_t& ranges);

    inline void resize_if_needed(uint64_t id);

protected:
    /**
     * @brief update_or_add_new_range - Indexes a single id
     * @param id - The id to be indexed
     * @param line - The global index (offset) of the given id
     */
    inline void update_or_add_new_range(uint64_t id, uint64_t line);

private:
    uint64_t length_;
    neuron_index data_;
};

} // namespace syn2
