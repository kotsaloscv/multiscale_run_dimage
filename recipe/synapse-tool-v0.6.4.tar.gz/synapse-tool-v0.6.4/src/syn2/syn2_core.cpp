/*
 * Copyright (C) 2017 Adrien Devresse <adrien.devresse@epfl.ch>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
#include "nrn_reader.hpp"
#include "sonata_reader.hpp"
#include "syn2_common.hpp"
#include "syn2_reader.hpp"
#include <syn2/synapses_exceptions.hpp>
#include <syn2/synapses_properties.hpp>
#include <syn2/synapses_reader.hpp>
#include <syn2/synapses_utils.hpp>

#include <boost/filesystem.hpp>

#include <algorithm>
#include <array>


namespace syn2 {

namespace fs = ::boost::filesystem;

std::vector<std::int8_t> version_file = {0, 9};


std::mutex& hdf5_lock() {
    static std::mutex _hdf5lock;
    return _hdf5lock;
}

// all properties  and their associated string identifier
namespace property {


// pre and post neuron connection id
std::string connected_neurons_pre() {
    return "connected_neurons_pre";
}

std::string connected_neurons_post() {
    return "connected_neurons_post";
}

std::string delay() {
    return "delay";
}

std::string conductance() {
    return "conductance";
}

std::string u_syn() {
    return "u_syn";
}

std::string depression_time() {
    return "depression_time";
}

std::string facilitation_time() {
    return "facilitation_time";
}

std::string decay_time() {
    return "decay_time";
}

std::string absolute_efficacy() {
    return "absolute_efficacy";
}

std::string morpho_section_id_pre() {
    return "morpho_section_id_pre";
}

std::string morpho_section_distance_pre() {
    return "morpho_section_distance_pre";
}

std::string morpho_section_id_post() {
    return "morpho_section_id_post";
}

std::string morpho_section_distance_post() {
    return "morpho_section_distance_post";
}

std::string syn_type_id() {
    return "syn_type_id";
}

std::string junction_id_pre() {
    return "junction_id_pre";
}

std::string junction_id_post() {
    return "junction_id_post";
}

std::string synapse_index() {
    return "synapse_index";
}

std::string synapse_id() {
    return "synapse_id";
}

std::string position() {
    return "position";
}


std::string position_center_pre() {
    return "position_center_pre";
}

std::string position_center_post() {
    return "position_center_post";
}

std::string position_contour_pre() {
    return "position_contour_pre";
}

std::string position_contour_post() {
    return "position_contour_post";
}


} // namespace property


namespace population {

std::string default_population() {
    return "default";
}

} // namespace population


class dimension_visitor : public boost::static_visitor<> {
public:
    template <typename T>
    void operator()(const std::vector<T>& vec) {
        dims.push_back(vec.size());
    }


    void operator()(const mat_double& mat) {
        dims.push_back(mat.size1());
        dims.push_back(mat.size2());
    }

    std::vector<std::size_t> dims;
};


std::vector<std::size_t> property_vec_get_dim(const property_vec& property) {
    dimension_visitor visitor;
    boost::apply_visitor(visitor, property);
    return std::move(visitor.dims);
}


property_type property_vec_get_type(const property_vec& property) {
    return property_type(property.which());
}


vec_uint retrieve_synapse_index(const multirange_synapse& ranges) {
    vec_uint syn_ids;

    // For each range, extend the index vector with sequential ids, starting at range[0]
    for (const auto& range : ranges) {
        if (range[0] == range[1]) {
            continue;
        }
        auto vec_size = syn_ids.size();
        syn_ids.resize(vec_size + range[1] - range[0]);
        std::iota(syn_ids.begin() + vec_size, syn_ids.end(), range[0]);
    }

    return syn_ids;
}


// options

class options::options_iternal {
public:
    inline options_iternal()
          : with_mpi(false)
          , verbose(0) {}

    bool with_mpi;
    int verbose;
};

options::options()
      : _dptr(new options_iternal()) {}

options::~options() {}

options& options::with_mpi(bool mpi_mode) {
    _dptr->with_mpi = mpi_mode;
    return *this;
}

options& options::verbose(int level) {
    _dptr->verbose = level;
    return *this;
}

bool options::is_with_mpi() const {
    return _dptr->with_mpi;
}

int options::is_verbose() const {
    return _dptr->verbose;
}

// synapses reader

synapses_reader_interface::~synapses_reader_interface() {}


std::string _find_synapse_file(const fs::path& dir) {
    auto pth_sonata = dir / "edges.sonata";
    auto pth_syn2 = dir / "circuit.syn2";

    if (fs::exists(pth_sonata) || fs::exists(pth_syn2)) {
        std::cerr << "Synapsetool: [WARNING] New Circuits should be given in full path"
                  << std::endl;
        if (fs::exists(pth_sonata)) {
            return pth_sonata.string();
        }
        return pth_syn2.string();
    }

    // [Compat] nrn circuts can be given as a directory, as long as there's a nrn.h5 inside
    auto pth_nrn = fs::path(dir) / "nrn.h5";
    if (fs::exists(pth_nrn)) {
        return pth_nrn.string();
    }

    // No further fallbacks
    throw std::invalid_argument("Synapsetool: No suitable file found in provided dir. "
                                "Full file paths are recommended.");
}


synapses_reader::synapses_reader(std::string filepath, const options& opt)
      : _dptr(nullptr) {
    fs::path pth(filepath);

    if (fs::is_directory(pth)) {
        filepath = _find_synapse_file(pth);
    }

    // ===  Handle full paths ===

    // sonata / syn2 recognized by extension (.sonata, .syn2)
    const auto file_ext = fs::path(filepath).extension().string();
    if (file_ext == ".sonata") {
        _dptr.reset(new sonata_reader(filepath, opt));
    } else if (file_ext == ".syn2") {
        _dptr.reset(new syn2_reader(filepath, opt));
    }
    // If .h5 we look for the /edges dataset (Sonata) or synapses (Syn2)
    else if (file_ext == ".h5") {
        HighFive::File h5file(filepath);
        if (h5file.exist("/edges")) {
            _dptr.reset(new sonata_reader(filepath, opt));
        } else if (h5file.exist("/synapses")) {
            _dptr.reset(new syn2_reader(filepath, opt));
        } else {
            // Still NRN?
            _dptr.reset(new nrn_reader(filepath, opt));
        }
    } else {
        throw std::invalid_argument("Synapsetool: Unknown synapse format");
    }
}

synapses_reader::~synapses_reader() {}


std::size_t synapses_reader::get_number_synapses() {
    return _dptr->get_number_synapses();
}


property_vec synapses_reader::get_property(const std::string& property,
                                           const selection& slice) {
    return _dptr->get_property(property, slice);
}


std::vector<std::string> synapses_reader::list_property_names(bool include_virtual) {
    return _dptr->list_property_names(include_virtual);
}

std::vector<std::string> synapses_reader::list_populations() {
    return _dptr->list_populations();
}

void synapses_reader::select_population(const std::string& population_name) {
    _dptr->select_population(population_name);
}


//
//
// synapses selection
//
//

//
// Interface for selection of synapses subset
//
class selection_internal {
public:
    struct pre_id {
        inline pre_id(std::uint64_t my_id)
              : id(my_id) {}

        std::uint64_t id;
    };

    struct post_id {
        inline post_id(std::uint64_t my_id)
              : id(my_id) {}

        std::uint64_t id;
    };

    struct range_syn {
        inline range_syn(std::uint64_t my_start, std::uint64_t my_end)
              : srange() {
            // gcc 4.7.4 of BGQ does not support bracket initialization properly
            srange[0] = my_start;
            srange[1] = my_end;
        }
        std::array<std::uint64_t, 2> srange;
    };

    typedef boost::variant<pre_id, post_id, range_syn> criteria;

    std::vector<criteria> criterias;
};

selection::selection()
      : _dptr(new selection_internal()) {}

selection::~selection() {}

selection::selection(selection&& other) {
    this->swap(other);
}

selection& selection::operator=(selection&& other) {
    this->swap(other);
    return *this;
}

selection selection::all() {
    return selection();
}

selection selection::synapse_range(std::size_t start, std::size_t end) {
    selection res;
    res._dptr->criterias.push_back(selection_internal::range_syn(start, end));
    return res;
}

selection selection::by_post_neuron_id(uint64_t id) {
    selection res;
    res._dptr->criterias.push_back(selection_internal::post_id(id));
    return res;
}


selection selection::by_pre_neuron_id(uint64_t id) {
    selection res;
    res._dptr->criterias.push_back(selection_internal::pre_id(id));
    return res;
}


std::vector<std::uint64_t> selection::post_synaptic_ids() const {
    std::vector<std::uint64_t> all_post_ids;

    for (selection_internal::criteria& c : _dptr->criterias) {
        if (c.which() == 1) {
            all_post_ids.push_back(boost::get<selection_internal::post_id>(c).id);
        }
    }

    return all_post_ids;
}


std::vector<std::uint64_t> selection::pre_synaptic_ids() const {
    std::vector<std::uint64_t> all_pre_ids;

    for (selection_internal::criteria& c : _dptr->criterias) {
        if (c.which() == 0) {
            all_pre_ids.push_back(boost::get<selection_internal::pre_id>(c).id);
        }
    }

    return all_pre_ids;
}


std::vector<std::array<std::uint64_t, 2>> selection::all_synapse_ranges() const {
    std::vector<std::array<std::uint64_t, 2>> all_ranges;

    for (selection_internal::criteria& c : _dptr->criterias) {
        if (c.which() == 2) {
            all_ranges.push_back(boost::get<selection_internal::range_syn>(c).srange);
        }
    }

    return all_ranges;
}


void selection::swap(selection& other) {
    std::swap(_dptr, other._dptr);
}


} // namespace syn2
