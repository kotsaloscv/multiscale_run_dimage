/*
 * Copyright (C) 2017-2020 Blue Brain Project
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
#pragma once

#include <chrono>
#include <stdexcept>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

namespace chrono = std::chrono;

class ProgressBar {
public:
    ProgressBar(size_t total, bool show_bar)
          : total_(total)
          , show_bar_(show_bar) {
        if (total <= 0)
            throw std::runtime_error("Total tasks in progress cant be zero");
        update(0);
    }

    ProgressBar(size_t total = 100)
          : ProgressBar(total, isatty(STDERR_FILENO)) {}

    ~ProgressBar() {
        if (show_bar_)
            clear();
    }


    /**
     * @brief update : Updates the progress bar
     * @param tasks_done The number of tasks done
     */
    void update(const size_t tasks_done) {
        tasks_done_ = tasks_done;
        if (show_bar_)
            _show();
    }

    void next() {
        tasks_done_++;
        if (show_bar_)
            _show();
    }


protected:
    static const int MAX_BAR_LEN = 100;

    inline void _show() {
        static const char* PB_STR = "=================================================="
                                    "==================================================";

        chrono::time_point<chrono::system_clock> t = chrono::system_clock::now();
        auto fp_ms = t - t0;
        if (fp_ms < chrono::milliseconds(100) && tasks_done_ < total_ && tasks_done_ > 0) {
            // Will show first, last and at most once every 0.1 sec
            return;
        }

        t0 = t;
        float progress = (float)tasks_done_ / total_;
        int cols = window_cols() - 1;

        char tasks_str[30];
        sprintf(tasks_str, "(%ld / %ld)", tasks_done_, total_);

        int progress_len = cols - (11 + strlen(tasks_str));
        if (progress_len > MAX_BAR_LEN) {
            progress_len = MAX_BAR_LEN;
        }

        int bar_len = (int)(progress * progress_len);
        int rpad = progress_len - bar_len;
        last_msg_len = progress_len + 11 + strlen(tasks_str);

        fprintf(stderr, "\r[%5.1f%%|%.*s>%*s] %s", progress * 100, bar_len, PB_STR, rpad,
                "", tasks_str);
    }


    void clear() {
        fprintf(stderr, "\r%*s\r", last_msg_len, "");
    }


private:
    static inline int window_cols() {
        struct winsize window;
        int columns = 80;

        if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &window) >= 0) {
            if (window.ws_col > 0)
                columns = window.ws_col;
        }
        return columns;
    }

    const size_t total_;
    size_t tasks_done_ = 0;
    int last_msg_len = 0;
    const bool show_bar_;
    chrono::time_point<chrono::system_clock> t0 = chrono::system_clock::now();
};
