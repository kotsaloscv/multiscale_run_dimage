/*
 * Copyright (C) 2017 Adrien Devresse <adrien.devresse@epfl.ch>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
#pragma once

#include "syn2_common.hpp"
#include <syn2/synapses_reader.hpp>
#include <syn2/synapses_selection.hpp>
#include <syn2/synapses_utils.hpp>

#include <highfive/H5File.hpp>


namespace syn2 {

///
/// \brief synapse file reader
///
class syn2_reader : public synapses_reader_interface {
public:
    struct index_neuron;

    syn2_reader(const std::string& filename, const options& opt);
    virtual ~syn2_reader();


    std::size_t get_number_synapses() override;


    property_vec get_property(const std::string& property, const selection& slice) override;


    std::vector<std::string> list_property_names(bool include_virtual = true) override;


    std::vector<std::string> list_populations() override;


    void select_population(const std::string& population_name) override;


private:
    std::string _filename;
    std::string _population;

    std::unique_ptr<HighFive::File> _file;
    bool _verbose;

    std::unique_ptr<index_neuron> _index_neuron_pre, _index_neuron_post;

    void open_indexes();

    void resolve_selection(const selection& s, multirange_synapse& ranges, bool& full);
};


} // namespace syn2
