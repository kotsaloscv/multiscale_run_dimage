/*
 * Copyright (C) 2018 Blue Brain Project
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
#include "sonata_reader.hpp"
#include "syn2_common.hpp"
#include "translation.hpp"
#include <syn2/synapses_exceptions.hpp>


namespace snt = bbp::sonata;

namespace {

template <typename T>

std::vector<T> _to_vector(const std::set<T>& values) {
    return std::vector<T>(values.begin(), values.end());
}

} // unnamed namespace


namespace syn2 {

using translation::Naming;

sonata_reader::sonata_reader(const std::string& filename, const options& opts)
      : _to_sonata(Naming::get_property_mapping<
                   static_cast<std::size_t>(synapse_file_format::syn2),
                   static_cast<std::size_t>(synapse_file_format::sonata)>())
      , _from_sonata(Naming::get_property_mapping<
                     static_cast<std::size_t>(synapse_file_format::sonata),
                     static_cast<std::size_t>(synapse_file_format::syn2)>())
      , _verbose(opts.is_verbose()) {
    std::lock_guard<std::mutex> _l(hdf5_lock());
    _storage.reset(new snt::EdgeStorage(filename));

    const auto& populations = _storage->populationNames();
    if (populations.empty()) {
        throw syn_exception(error_code::file_access_error,
                            "Sonata file doesnt constain any population");
    }

    // Attempt to load the default or single population
    std::string popname;
    if (populations.count(population::default_population())) {
        popname = population::default_population();
    } else if (populations.size() == 1) {
        popname = *populations.begin();
    }

    if (not popname.empty()) {
        if (_verbose) {
            std::cout << "[SynTool] Auto-Opening population: '" << popname << "'"
                      << std::endl;
        }
        _population = _storage->openPopulation(popname);
    }
}


sonata_reader::~sonata_reader() {}


std::size_t sonata_reader::get_number_synapses() {
    std::lock_guard<std::mutex> _l(hdf5_lock());
    return _population->size();
}


std::vector<std::string> sonata_reader::list_property_names(bool include_virtual) {
    std::lock_guard<std::mutex> _l(hdf5_lock());
    std::set<std::string> properties;

    for (const auto& prop : _population->attributeNames()) {
        const auto it = _from_sonata.find(prop);
        if (it != _from_sonata.end()) {
            properties.emplace(it->second);
        } else {
            properties.emplace(prop);
        }
    }

    std::vector<std::string> extra_properties{
        property::connected_neurons_pre(),
        property::connected_neurons_post()
    };
    if (include_virtual) {
        extra_properties.push_back(property::synapse_index());
    }
    for (const auto& prop : extra_properties) {
        if (!properties.insert(prop).second) {
            throw syn_exception(error_code::invalid_layout,
                                std::string("Unexpected attribute name: ") + prop);
        }
    }
    return _to_vector(properties);
}


std::vector<std::string> sonata_reader::list_populations() {
    std::lock_guard<std::mutex> _l(hdf5_lock());
    return _to_vector(_storage->populationNames());
}


void sonata_reader::select_population(const std::string& population_name) {
    std::lock_guard<std::mutex> _l(hdf5_lock());
    _population = _storage->openPopulation(population_name);
}


std::string sonata_reader::_resolve_property(const std::string& property) const {
    const auto it = _to_sonata.find(property);
    if (it == _to_sonata.end()) {
        return property;
    }

    const std::string resolved_property = it->second;

    // support sonata files with syn2 names in some old crcuit: when an attribute is
    // translated, but the translation is not present in the list of properties,
    // attempt to use the original property name.
    if (_population->attributeNames().count(resolved_property) == 0) {
        if (_population->attributeNames().count(property) > 0) {
            if (_verbose == 2) {
                std::cerr << "Using untranslated property: " << property << std::endl;
            }
            return property;
        }
        if (_verbose == 2) {
            std::cerr << "Entries in translation table:" << std::endl;
            for (const auto& entry : _to_sonata) {
                std::cerr << "  " << entry.first << " -> " << entry.second << std::endl;
            }
        }
        throw syn_exception(error_code::invalid_dataset_name,
                            property + " (SONATA: " + resolved_property + ") doesnt exist");
    }

    if (_verbose == 2) {
        std::cout << "Using translation: " << property << " -> " << resolved_property
                  << std::endl;
    }

    return resolved_property;
}


snt::Selection sonata_reader::_resolve_selection(const selection& slice) const {
    // NB: unprotected access to _population;
    // it's the responsitibility of a public method to ensure mutex is acquired
    const auto all_ranges = slice.all_synapse_ranges();
    if (!all_ranges.empty()) {
        snt::Selection::Ranges ranges;
        ranges.reserve(all_ranges.size());
        for (const auto& r : all_ranges) {
            ranges.emplace_back(r[0], r[1]);
        }
        return snt::Selection(std::move(ranges));
    }

    const auto post_ids = slice.post_synaptic_ids();
    if (!post_ids.empty()) {
        return _population->afferentEdges(post_ids);
    }

    const auto pre_ids = slice.pre_synaptic_ids();
    if (!pre_ids.empty()) {
        return _population->efferentEdges(pre_ids);
    }

    // select all
    return snt::Selection({{0, _population->size()}});
}


property_vec sonata_reader::get_property(const std::string& property,
                                         const selection& slice) {
    std::lock_guard<std::mutex> _l(hdf5_lock());

    const auto select = _resolve_selection(slice);

    if (property == property::connected_neurons_pre()) {
        return _population->sourceNodeIDs(select);
    }
    if (property == property::connected_neurons_post()) {
        return _population->targetNodeIDs(select);
    }
    if (property == property::synapse_index()) {
        // Sonata and syn2 ranges are the same, except sonata uses pair instead of std::array
        return retrieve_synapse_index(
          *reinterpret_cast<const multirange_synapse*>(&select.ranges()));
    }

    const std::string resolved_property = _resolve_property(property);
    const auto dtype = _population->_attributeDataType(resolved_property);
    if (dtype == "int8_t") {
        return property_vec(
          _population->getAttribute<vec_int::value_type>(resolved_property, select));
    } else if (dtype == "uint8_t") {
        return property_vec(
          _population->getAttribute<vec_byte::value_type>(resolved_property, select));
    } else if (dtype == "int16_t") {
        return property_vec(
          _population->getAttribute<vec_int::value_type>(resolved_property, select));
    } else if (dtype == "uint16_t") {
        return property_vec(
          _population->getAttribute<vec_uint::value_type>(resolved_property, select));
    } else if (dtype == "int32_t") {
        return property_vec(
          _population->getAttribute<vec_int::value_type>(resolved_property, select));
    } else if (dtype == "uint32_t") {
        return property_vec(
          _population->getAttribute<vec_uint::value_type>(resolved_property, select));
    } else if (dtype == "int64_t") {
        return property_vec(
          _population->getAttribute<vec_int::value_type>(resolved_property, select));
    } else if (dtype == "uint64_t") {
        return property_vec(
          _population->getAttribute<vec_uint::value_type>(resolved_property, select));
    } else if (dtype == "float") {
        return property_vec(
          _population->getAttribute<vec_double::value_type>(resolved_property, select));
    } else if (dtype == "double") {
        return property_vec(
          _population->getAttribute<vec_double::value_type>(resolved_property, select));
    } else {
        throw syn_exception(error_code::invalid_data_type,
                            std::string("Invalid datatype for dataset '") +
                              resolved_property + "'");
    }
}

} // namespace syn2
