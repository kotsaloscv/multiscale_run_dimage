/*
 * Copyright (C) 2017 Adrien Devresse <adrien.devresse@epfl.ch>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include <syn2/synapses_reader.hpp>

// How to read synapses both SYN2 and NRN file format
int main(int argc, char** argv){
    using namespace syn2;

    if (argc < 2) {
        std::cerr << "Usage " << argv[0] << " [synapse_file]" << std::endl;
    }

    synapses_reader reader(argv[1]);

    // let's determine the number of synapses
    std::cout << " this file contains " << reader.get_number_synapses() << " synapses " << std::endl;

    // we want to read ALL the pre-synaptic GID associated to each synapse
    property_vec all_presynaptic_gid = reader.get_property(property::connected_neurons_pre());

    // property vec for GIDs is vec_uint, a vector of std::uint64_t
    vec_uint& all_my_gids = boost::get<vec_uint>(all_presynaptic_gid);

    // print the first gid for synapse number 10
    std::cout << "pre-synaptic GID for synapse number 10: " << all_my_gids[10] << std::endl;

    return 0;
}
