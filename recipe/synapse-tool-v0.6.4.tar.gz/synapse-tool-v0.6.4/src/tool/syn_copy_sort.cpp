/*
 * Copyright (C) 2017 Adrien Devresse <adrien.devresse@epfl.ch>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include <boost/variant/polymorphic_get.hpp>

#include <syn2/synapses_reader.hpp>
#include <syn2/synapses_writer.hpp>

#include "performance_helpers.hpp"
#include "syn2_utils.hpp"

#include <algorithm> // std::transform
#include <memory> // std::make_unique
#include <numeric> // std::iota

using syn2::log_step;
using syn2::synapses_reader;
using syn2::synapses_writer;
using syn2::property_vec;
using syn2::vec_int;
using syn2::vec_uint;

using time_counter_milli = syn2::time_counter<std::chrono::milliseconds>;

namespace {

struct copy_status {
    copy_status() = default;

    void inc_phase(){
        ++phase_counter;
    }

    // phase-step counter
    std::size_t phase_counter = 0;
    bool logger_enabled = true;

    // time measurement
    std::chrono::milliseconds io_time;
    std::chrono::milliseconds sort_time;
    std::chrono::milliseconds total_time;
};

// extract position ids
// sort every element and keep the previous position ids
struct ids_extractor : public boost::static_visitor<>{
    ids_extractor() = default;

    void operator() (syn2::mat_double &){
        throw syn2::syn_exception(syn2::error_code::operation_not_supported,
                                  "Impossible to sort based on multi-dimentional property");
    }

    template<typename Vec>
    void operator ()(Vec & vec){
        using v_type = typename Vec::value_type;
        using indexed_element = std::tuple<std::size_t, v_type>;

        std::vector<indexed_element> index_elems;

        // assign array
        index_elems.reserve(vec.size());
        std::size_t counter = 0;
        for(const v_type & elem : vec){
            index_elems.emplace_back(counter, elem);
            counter++;
        }

        // sort all elements per value
        // use a stable sort to preserve homomorphysm in case of multiple sorting A -> B -> C -> A
        std::stable_sort(index_elems.begin(),
                         index_elems.end(),
                         [](const indexed_element & e1, const indexed_element & e2)
                         {return (std::get<1>(e1) < std::get<1>(e2));});

        // extract indexes
        ids.reserve(vec.size());
        std::transform(index_elems.begin(),
                       index_elems.end(),
                       std::back_inserter(ids),
                       [](const indexed_element& i)
                       { return std::get<0>(i);});
    }

    std::vector<std::size_t> ids;
};

// extract position ids
// sort every element and keep the previous position ids
struct order_by_position : public boost::static_visitor<>{
    order_by_position(const std::vector<std::size_t> & position_index)
    : _positions_index(position_index)
    , _ordered_prop()
    {}

    void operator() (syn2::mat_double & mat){
        const std::size_t number_elems = mat.size1();
        syn2::mat_double ordered_elems(number_elems, mat.size2());

        check_property_size(number_elems);

        for(std::size_t i = 0; i < number_elems; ++i){
            const std::size_t position_source = _positions_index[i];
            assert(position_source < number_elems);

            for(std::size_t j = 0; j < mat.size2(); ++j){
                ordered_elems(i, j) = mat(position_source,j);
            }
        }
        _ordered_prop = property_vec(std::move(ordered_elems));
    }

    template<typename Vec>
    inline void operator ()(Vec & vec){
        Vec ordered_elems;
        const std::size_t number_elems = vec.size();

        check_property_size(number_elems);

        ordered_elems.reserve(number_elems);

        for(std::size_t i =0; i < number_elems; ++i){
            const std::size_t position_source = _positions_index[i];
            assert(position_source < number_elems);

            ordered_elems.emplace_back(vec[position_source]);
        }
        _ordered_prop = property_vec(std::move(ordered_elems));
    }

    void check_property_size(const std::size_t s){
        if(s != _positions_index.size()){
            throw syn2::syn_exception(syn2::error_code::invalid_layout,
                                      std::string("Property with invalid layout ") + std::to_string(s) + " != " + std::to_string(_positions_index.size()) + " rows ");
        }
    }

    std::vector<std::size_t> const & _positions_index;
    property_vec _ordered_prop;
};

void write_property_vector(copy_status& status,
                           synapses_writer& writer,
                           const std::string& property,
                           const property_vec& property_data)
{
    time_counter_milli write_time_probe(status.io_time);

    auto dims = syn2::property_vec_get_dim(property_data);
    auto type = syn2::property_vec_get_type(property_data);

    log_step(status, std::string(" -- Open/Create destination property ") + property);

    syn2::property_writer pwriter = writer.open_or_create(property, type, dims);

    log_step(status, std::string(" -- Write property ") + property);
    pwriter.pwrite(property_data);
}

void copy_properties_by_sorted_ids(copy_status& status,
                                   synapses_reader& reader,
                                   synapses_writer& writer,
                                   const std::vector<std::string>& properties,
                                   const std::vector<std::size_t>& sorted_ids)
{
    log_step(status, "Start Load, Sort, Write for every property ");

    for(const std::string & property : properties){
        log_step(status, std::string(" -- Read property ") + property);
        property_vec property_data;

        {
            time_counter_milli read_time_probe(status.io_time);
            property_data = reader.get_property(property);
        }

        log_step(status, " -- Sort data ");
        order_by_position ordering_visitor(sorted_ids);
        {
            time_counter_milli sort_time_probe(status.sort_time);

            boost::apply_visitor(ordering_visitor, property_data);
        }

        write_property_vector(status, writer, property, ordering_visitor._ordered_prop);
    }
}

void copy_properties_sorted(copy_status& status,
                            synapses_reader& reader,
                            synapses_writer& writer,
                            const std::vector<std::string>& properties,
                            const std::string & sort_by_property){

    std::vector<std::size_t> sorted_ids;

    {
        {
            property_vec property_data;
            {
                time_counter_milli read_time_probe(status.io_time);
                log_step(status, std::string("Load property to sort ") + sort_by_property + " ");
                property_data = reader.get_property(sort_by_property);
            }

            status.inc_phase();

            {
                log_step(status, std::string("Extract and sort indices from ") + sort_by_property);
                time_counter_milli sort_time_probe(status.sort_time);

                ids_extractor extractor;
                boost::apply_visitor(extractor, property_data);
                sorted_ids.swap(extractor.ids);
            }
        }

        status.inc_phase();

        copy_properties_by_sorted_ids(status, reader, writer, properties, sorted_ids);
    }
}

void copy_properties(copy_status& status,
                     synapses_reader& reader,
                     synapses_writer& writer,
                     const std::vector<std::string>& properties){

    for(const std::string & property : properties){
        log_step(status, std::string(" -- Read property ") + property + "");
        property_vec property_data;

        {
            time_counter_milli read_time_probe(status.io_time);
            property_data = reader.get_property(property);

        }
        write_property_vector(status, writer, property, property_data);
    }
}
} // namespace

void copy_population(const std::string & source,
                     const std::string & dest,
                     const std::string& population_arg,
                     const std::string& sort_by_arg){

    copy_status status {};

    std::size_t nb_synapses;
    std::string population;
    std::vector<std::string> properties;

    std::unique_ptr<synapses_reader> reader;
    std::unique_ptr<synapses_writer> writer;

    {
        time_counter_milli total_time_probe(status.total_time);
        std::cout << "Copy synapse file" << source << " to " << dest << std::endl;

        {
            time_counter_milli io_time_probe(status.io_time);
            log_step(status, std::string("Open source file ") + source);
            reader.reset(new synapses_reader(source));
        }

        status.inc_phase();

        {
            log_step(status, std::string("Select population in ") + source);

            population = syn2::get_selected_population_name(population_arg, reader->list_populations());
            log_step(status, std::string(" -- population selected:  ") + population);
            reader->select_population(population);
        }

        status.inc_phase();

        {
            time_counter_milli io_time_probe(status.io_time);
            log_step(status, std::string("Get population metadata "));

            nb_synapses = reader->get_number_synapses();

            log_step(status, std::string(" -- ") + std::to_string(nb_synapses) + " synapses found");

            properties = reader->list_property_names(false);

            std::string concat_properties;
            std::for_each(properties.begin(), properties.end(),[&](const std::string & str){
                if( ! concat_properties.empty()){
                    concat_properties.append(" ");
                }
                concat_properties.append(str);
            });

            log_step(status, std::string(" -- list of properties: [ ") + concat_properties + " ]");
        }

        status.inc_phase();

        {
            time_counter_milli io_time_probe(status.io_time);
            log_step(status, std::string("Create destination file ") + dest);

            writer = std::make_unique<synapses_writer>(dest, synapses_writer::override_file_flag | synapses_writer::create_flag);
        }

        status.inc_phase();

        {
            time_counter_milli write_time_probe(status.io_time);
            writer->select_population(population);
            log_step(status, std::string("Pre-allocate space in destination file "));
            writer->resize(nb_synapses);
        }

        status.inc_phase();

        const std::string sort_by_property = sort_by_arg;
        if(sort_by_property.empty()){
            copy_properties(status, *reader, *writer, properties);
        } else{
            copy_properties_sorted(status,
                                   *reader,
                                   *writer,
                                   properties,
                                   sort_by_property);
        }

        status.inc_phase();

        {
            log_step(status, std::string("Create indexes"));
            writer->create_all_index();
        }

        status.inc_phase();
    }

    log_step(status, std::string("Copy from ") + source + " to " + dest + " done with success");
    log_step(status, std::string(" Stats: "));
    log_step(status, std::string("  -- Total time: ") + std::to_string(double(status.total_time.count())/1000.0) + " s");
    log_step(status, std::string("  -- I/O time: ") + std::to_string(double(status.io_time.count())/1000.0) + " s");
    log_step(status, std::string("  -- Shuffle time: ") + std::to_string(double(status.sort_time.count())/1000.0) + " s");
}

std::vector<std::size_t> dual_sorted_ids(copy_status& status,
                                         synapses_reader& reader,
                                         bool afferent)
{
    std::string prop0_name;
    std::string prop1_name;

    if(afferent) {
        prop0_name = syn2::property::connected_neurons_post();
        prop1_name = syn2::property::connected_neurons_pre();
    } else {
        prop0_name = syn2::property::connected_neurons_pre();
        prop1_name = syn2::property::connected_neurons_post();
    }

    log_step(status, "loading id properties");
    std::vector<std::size_t> sorted_ids;

    auto sorta = [&](const auto& p0, const auto& p1) {
        log_step(status, "assign array");
        sorted_ids.resize(p0.size());
        std::iota(sorted_ids.begin(), sorted_ids.end(), std::size_t(0));

        log_step(status, "sort indices");
        std::stable_sort(sorted_ids.begin(), sorted_ids.end(),
                         [&p0, &p1](size_t i0, size_t i1)
                         {return (p0[i0] < p0[i1]) ||
                                  (p0[i0] == p0[i1] && p1[i0] < p1[i1]);});
    };

    try {
        const vec_int prop0 = boost::get<vec_int>(reader.get_property(prop0_name));
        const vec_int prop1 = boost::get<vec_int>(reader.get_property(prop1_name));

        sorta(prop0, prop1);

    } catch (const boost::bad_get&) {
        const vec_uint prop0 = boost::get<vec_uint>(reader.get_property(prop0_name));
        const vec_uint prop1 = boost::get<vec_uint>(reader.get_property(prop1_name));

        sorta(prop0, prop1);
    }

    return sorted_ids;
}

int order_synapses(const std::string& source,
                   const std::string& dest,
                   const std::string& population_arg,
                   bool afferent)
{
    std::unique_ptr<synapses_writer> writer;
    copy_status status {};

    {
        synapses_reader reader(source);

        writer = std::make_unique<synapses_writer>(
            dest, synapses_writer::override_file_flag | synapses_writer::create_flag);

        auto sorted_ids = dual_sorted_ids(status, reader, afferent);

        log_step(status, "select population");
        auto population = syn2::get_selected_population_name(population_arg,
                                                             reader.list_populations());
        writer->select_population(population);

        log_step(status, "resize hdf5 container");
        writer->resize(sorted_ids.size());

        log_step(status, "copy properties by sorted ids");
        const auto properties = reader.list_property_names(false);
        copy_properties_by_sorted_ids(status, reader, *writer, properties, sorted_ids);
    }

    writer->create_all_index();

    return 0;
}
