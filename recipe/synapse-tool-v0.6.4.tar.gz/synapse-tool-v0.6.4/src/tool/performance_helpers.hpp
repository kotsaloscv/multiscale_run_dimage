#ifndef PERFORMANCE_HELPERS_HPP
#define PERFORMANCE_HELPERS_HPP


#include <chrono>


namespace syn2 {


template<typename Duration>
class time_counter{
public:
    time_counter(Duration & d):
        _d(d),
        _point(std::chrono::steady_clock::now())
    {
    }

    ~time_counter(){
        auto time_spent = std::chrono::steady_clock::now() - _point;
        _d = _d + std::chrono::duration_cast<Duration>(time_spent);
    }

private:
    Duration & _d;
    std::chrono::steady_clock::time_point _point;

};


template<typename Status>
inline void log_step(const Status & status, const std::string & msg){
    if(status.logger_enabled){
        std::cout << " " << status.phase_counter << ": " << msg << "\n";
    }
}


} // syn2


#endif // PERFORMANCE_HELPERS_HPP
