/*
 * Copyright (C) 2017 Adrien Devresse <adrien.devresse@epfl.ch>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */


#include <syn2/synapses_reader.hpp>
#include <syn2/synapses_writer.hpp>
#include <syn2/synapses_exceptions.hpp>


#ifdef SYNTOOL_WITH_MPI
#include <mpi-cpp/mpi.hpp>
#endif

#include "performance_helpers.hpp"

using namespace syn2;

namespace {

struct conversion_status{
    inline conversion_status() :
        phase_counter(0),
        logger_enabled(true),
        total_time(0),
        read_time(0),
        write_time(0)
    {}

    inline void inc_phase(){
        phase_counter ++;
    }

    // phase-step counter
    std::size_t phase_counter;
    bool logger_enabled;


    // time measurement
    std::chrono::milliseconds total_time;
    std::chrono::milliseconds read_time;
    std::chrono::milliseconds write_time;
};


void print_stats(const conversion_status & status){
    log_step(status, std::string(" Stats: "));
    log_step(status, std::string("  -- Total time: ") + std::to_string(double(status.total_time.count())/1000.0) + " s");
    log_step(status, std::string("  -- Read source file time: ") + std::to_string(double(status.read_time.count())/1000.0) + " s");
    log_step(status, std::string("  -- Write dest file time: ") + std::to_string(double(status.write_time.count())/1000.0) + " s");
}


}


void convert_syn_files(const std::string & source, const std::string & dest, const std::string& pop, const std::string& nsrc, const std::string& ndst){

    struct conversion_status status;

    std::size_t nb_synapses = 0;
    std::unique_ptr<synapses_reader> reader;
    std::unique_ptr<synapses_writer> writer;

    {
        time_counter<std::chrono::milliseconds> total_time_probe(status.total_time);

        std::cout << "Start conversion from " << source << " to " << dest << std::endl;

        {
            time_counter<std::chrono::milliseconds> read_time_probe(status.read_time);

            log_step(status, std::string("Open source file ") + source);

            reader.reset(new synapses_reader(source));

            status.inc_phase();
        }

        {
            time_counter<std::chrono::milliseconds> write_time_probe(status.write_time);

            log_step(status, std::string("Create destination file ") + dest);

            writer = std::unique_ptr<synapses_writer>(new synapses_writer(dest, synapses_writer::override_file_flag | synapses_writer::create_flag));
            writer->select_population(pop);

            status.inc_phase();
        }

        {
            time_counter<std::chrono::milliseconds> read_time_probe(status.read_time);

            log_step(status, std::string("Compute number of synapses "));

            nb_synapses = reader->get_number_synapses();

            log_step(status, std::string(" -- ") + std::to_string(nb_synapses) + " synapses found");

            status.inc_phase();
        }

        {
            time_counter<std::chrono::milliseconds> write_time_probe(status.write_time);

            log_step(status, std::string("Pre-allocate space in destination file "));

            writer->resize(nb_synapses);

            status.inc_phase();

        }

        std::vector<std::string> all_properties = reader->list_property_names();


        log_step(status, std::string("Convert and copy every property"));

        for(const std::string & property : all_properties){
            property_vec property_data;

            {
                time_counter<std::chrono::milliseconds> read_time_probe(status.read_time);

                log_step(status, std::string(" -- load property ") + property + " ");

                property_data = reader->get_property(property);

            }

            {
                time_counter<std::chrono::milliseconds> write_time_probe(status.write_time);

                auto dims = property_vec_get_dim(property_data);
                auto type = property_vec_get_type(property_data);

                log_step(status, std::string(" -- Open/Create destination property ") + property);
                property_writer pwriter = writer->open_or_create(property, type, dims);

                log_step(status, std::string(" -- Convert property ") + property + " ");
                pwriter.pwrite(property_data);

            }

            log_step(status, std::string(" -- next "));


        }


        status.inc_phase();

    }

    {
        log_step(status, std::string("Create fake SONATA type field"));
        vec_byte pdata(reader->get_number_synapses(), 0);
        auto pwriter = writer->open_or_create(
            "synapse_type_id",
            property_type::vec_uint,
            std::vector<size_t>{pdata.size()}
        );
        pwriter.pwrite(pdata);
        status.inc_phase();
    }

    {
        log_step(status, std::string("Create indexes"));
        time_counter<std::chrono::milliseconds> write_time_probe(status.write_time);

        writer->create_all_index();
        // The grande finale: remove SYN2 naming and replace with SONATA
        writer->compose_sonata(true, nsrc, ndst);

        status.inc_phase();
    }

    log_step(status, std::string("Convertion from ") + source + " to " + dest + " done with success");
    print_stats(status);
}


#ifndef SYNTOOL_WITH_MPI
void convert_syn_files_mpi(const std::string & , const std::string &, const std::string &, const std::string&, const std::string&){
    throw syn_exception(error_code::operation_not_supported, "MPI support not enabled at compile time");
}
#else

void convert_syn_files_mpi(const std::string & source, const std::string & dest, const std::string& pop, const std::string& nsrc, const std::string& ndst){

    mpi::mpi_comm world_comm;


    struct conversion_status status;

    status.logger_enabled = (world_comm.is_master());

    std::size_t nb_synapses = 0;
    std::unique_ptr<synapses_reader> reader;
    std::unique_ptr<synapses_writer> writer;

    log_step(status, std::string("Start MPI conversion with ") + std::to_string(world_comm.size()) + " ranks");

    world_comm.barrier();

    {
        time_counter<std::chrono::milliseconds> total_time_probe(status.total_time);

        std::cout << "Start conversion from " << source << " to " << dest << std::endl;

        {
            time_counter<std::chrono::milliseconds> read_time_probe(status.read_time);

            log_step(status, std::string("Open source file ") + source);

            reader.reset(new synapses_reader(source));

            status.inc_phase();
        }

        world_comm.barrier();

        {
            time_counter<std::chrono::milliseconds> read_time_probe(status.read_time);

            log_step(status, std::string("Compute number of synapses "));

            if(world_comm.is_master()){
                nb_synapses = reader->get_number_synapses();
            }
            world_comm.broadcast(nb_synapses, 0);

            log_step(status, std::string(" -- ") + std::to_string(nb_synapses) + " synapses found");

            status.inc_phase();
        }

        world_comm.barrier();


    }

    world_comm.barrier();
    log_step(status, std::string("Convertion from ") + source + " to " + dest + " done with success");
    print_stats(status);
}

#endif
