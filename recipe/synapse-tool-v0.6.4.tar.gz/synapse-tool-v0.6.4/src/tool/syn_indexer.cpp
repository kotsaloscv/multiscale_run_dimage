/*
 * Copyright (C) 2017 Adrien Devresse <adrien.devresse@epfl.ch>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */
#include <exception>

#include <syn2/indexing.hpp>

#include <highfive/H5File.hpp>
#include <highfive/H5Version.hpp>

#include "performance_helpers.hpp"
#include "syn2_utils.hpp"

#ifdef SYNTOOL_WITH_MPI
#include "mpi-cpp/mpi.hpp"
#endif

using namespace syn2;

int create_index_for(const std::string& source, bool with_mpi, std::string population) {
    bool show_output = true;

#ifdef SYNTOOL_WITH_MPI
    if (with_mpi) {
        mpi::mpi_comm comm;
        show_output = comm.is_master();
    }
#endif

    std::chrono::milliseconds generate_time(0);

    if (show_output) {
        std::cout << "- Open file " << source << std::endl;
    }

    HighFive::File file(source, HighFive::File::ReadWrite,
#ifdef SYNTOOL_WITH_MPI
                        (with_mpi) ? HighFive::MPIOFileDriver(MPI_COMM_WORLD, MPI_INFO_NULL)
                                   :
#endif
#if HIGHFIVE_VERSION_MAJOR >= 2 && HIGHFIVE_VERSION_MINOR >= 3
                                   HighFive::FileAccessProps::Default());
#else
                                   HighFive::FileDriver());
#endif

    if (!file.exist("/edges")) {
        if (show_output) {
            std::cout << "-- File does not seem to be valid SONATA" << std::endl;
        }
        return 666;
    }

    auto edges = file.getGroup("/edges");

    if (population.empty()) {
        for (const auto& name : edges.listObjectNames()) {
            if (edges.getObjectType(name) == HighFive::ObjectType::Group) {
                if (!population.empty()) {
                    if (show_output) {
                        std::cout << "-- File contains more than one population!"
                                  << std::endl;
                    }
                    return 666;
                }
                population = name;
            }
        }
        if (population.empty()) {
            if (show_output) {
                std::cout << "-- File contains no populations!" << std::endl;
            }
            return 666;
        }
        if (show_output) {
            std::cout << "-- Using automatically determined population '" << population
                      << "'" << std::endl;
        }
    } else if (!file.exist("/edges/" + population)) {
        if (show_output) {
            std::cout << "-- Population '" << population << "' is not present!"
                      << std::endl;
        }
        return 666;
    }

    auto base = edges.getGroup(population);

    if (show_output) {
        std::cout << "- Generate Index" << std::endl;
    }

    size_t count = 0;

    {
        time_counter<std::chrono::milliseconds> counter(generate_time);

        auto there = get_or_create(base, "indices", "source_to_target");
        auto back = get_or_create(base, "indices", "target_to_source");
        auto primary_neuron_namespace = "node_id_to_ranges";
        auto secondary_neuron_namespace = "range_to_edge_id";
#ifdef SYNTOOL_WITH_MPI
        if (with_mpi) {
            count += edge::create_index_mpi(base.getDataSet("source_node_id"), there,
                                            primary_neuron_namespace,
                                            secondary_neuron_namespace);
            count += edge::create_index_mpi(base.getDataSet("target_node_id"), back,
                                            primary_neuron_namespace,
                                            secondary_neuron_namespace);
        } else
#endif
        {
            count += edge::create_index(base.getDataSet("source_node_id"), there,
                                        primary_neuron_namespace,
                                        secondary_neuron_namespace);
            count += edge::create_index(base.getDataSet("target_node_id"), back,
                                        primary_neuron_namespace,
                                        secondary_neuron_namespace);
        }
    }

    if (show_output) {
        std::cout << "- Index generated in " << double(generate_time.count()) / 1000.0
                  << "s " << std::endl
                  << std::endl;
    }

    return 2 - count;
}
