/*
 * Copyright (C) 2015 Adrien Devresse <adrien.devresse@epfl.ch>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
 *
 */

#include <exception>
#include <fstream>
#include <iostream>
#include <string>
#include <utility>
#include <vector>

#include "CLI/CLI.hpp"

#include "syn2_utils.hpp"

#ifdef SYNTOOL_WITH_MPI
#include <mpi-cpp/mpi.hpp>
#endif

extern void convert_syn_files(const std::string& nrn, const std::string& sonata, const std::string& pop, const std::string& src, const std::string& dst);
extern void convert_syn_files_mpi(const std::string& nrn, const std::string& sonata, const std::string& pop, const std::string& src, const std::string& dst);
extern void performance_syn_test(const std::string& file, const std::string& populationArg);
extern int create_index_for(const std::string& file,
                            bool with_mpi,
                            std::string populationArg);
extern void copy_population(const std::string& source,
                            const std::string& dest,
                            const std::string& populationArg,
                            const std::string& sort_byArg);
extern int order_synapses(const std::string& source,
                          const std::string& dest,
                          const std::string& populationArg,
                          bool afferent);

std::string version() {
    return std::string(SYN2_VERSION_MAJOR "." SYN2_VERSION_MINOR);
}

namespace syn2 {

struct Options {
    std::string population;
    std::string sort_by;
    bool with_mpi = false;
    bool version = false;
    std::string file1;
    std::string file2;
    bool efferent = false;

    std::string sonata_population;
    std::string source_population;
    std::string target_population;

    CLI::App* convert;
    CLI::App* perf;
    CLI::App* create_index;
    CLI::App* copy;
    CLI::App* order_synapses;
};

}

syn2::Options parse_args(int argc, char** argv) {
    syn2::Options options;

    CLI::App app{"A multitool to work with synapse files."};

    app.add_flag("--version", options.version, "output the version number");
    app.add_option("--population", options.population,
                   "select a synapse population to work on");
    app.add_option("--sort-by", options.sort_by,
                   "copy: choose a properties to sort by (e.g --sort-by=source_gid) ");
#ifdef SYNTOOL_WITH_MPI
    app.add_flag("--with-mpi", options.with_mpi,
                 "enable parallel computing with MPI if available ");
#endif

    app.require_subcommand(0, 1);

    options.convert = app.add_subcommand("convert", "convert synapse file");
    options.convert->add_option("nrn-file", options.file1, "")->required();
    options.convert->add_option("SONATA-file", options.file2, "SONATA file to create")->required();
    options.convert->add_option("SONATA-population", options.sonata_population, "population to write")->required();
    options.convert->add_option("source-population", options.source_population, "node source population to register")->required();
    options.convert->add_option("target-population", options.target_population, "node target population to register")->required();

    options.perf = app.add_subcommand("perf", "performance test");
    options.perf->add_option("file", options.file1, "")->required();

    options.create_index = app.add_subcommand("create-index",
                                              "create all indices for a synapse file");
    options.create_index->add_option("file", options.file1, "")->required();

    options.copy = app.add_subcommand("copy", "copy a population to a new file");
    options.copy->add_option("input_file", options.file1, "")->required();
    options.copy->add_option("output_file", options.file2, "")->required();

    options.order_synapses = app.add_subcommand(
      "order-synapses", "Order the synapses by afferent/efferent grouping");
    options.order_synapses->add_option("input_file", options.file1, "")->required();
    options.order_synapses->add_option("output_file", options.file2, "")->required();
    options.order_synapses->add_flag("--efferent", options.efferent,
                                     "Sort with efferent view; default is afferent");

    try {
        app.parse(argc, argv);
    } catch (const CLI::ParseError& e) {
        app.exit(e);
        throw;
    }

    return options;
}

int main(int argc, char** argv) {
    try {
        syn2::Options options = parse_args(argc, argv);

        if (options.version) {
            std::cout << "version: " << version() << std::endl;
            return 0;
        }

        if (*(options.convert)) {
#ifdef SYNTOOL_WITH_MPI
            if (options.with_mpi) {
                mpi::mpi_scope_env env(&argc, &argv);
                convert_syn_files_mpi(options.file1, options.file2, options.sonata_population, options.source_population, options.target_population);
            } else
#endif
            {
                convert_syn_files(options.file1, options.file2, options.sonata_population, options.source_population, options.target_population);
            }
        } else if (*(options.perf)) {
            performance_syn_test(options.file1, options.population);
        } else if (*(options.create_index)) {
#ifdef SYNTOOL_WITH_MPI
            if (options.with_mpi) {
                mpi::mpi_scope_env env(&argc, &argv);
                return create_index_for(options.file1, options.with_mpi,
                                        options.population);
            } else
#endif
                return create_index_for(options.file1, options.with_mpi,
                                        options.population);
        } else if (*(options.copy)) {
            copy_population(options.file1, options.file2, options.population,
                            options.sort_by);
        } else if (*(options.order_synapses)) {
            return order_synapses(options.file1, options.file2, options.population,
                                  /* afferent */ !options.efferent);
        }
    } catch (const CLI::ParseError& e) {
        return -1;
    } catch (std::exception& e) {
        std::cerr << "Fatal Error: " << e.what() << std::endl;
        return -1;
    }
    return 0;
}
