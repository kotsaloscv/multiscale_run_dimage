/*
 * Copyright (C) 2017 Adrien Devresse <adrien.devresse@epfl.ch>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include <chrono>
#include <random>

#include <syn2/synapses_reader.hpp>
#include <syn2/synapses_writer.hpp>

#include "performance_helpers.hpp"
#include "syn2_utils.hpp"

using namespace syn2;

const std::string test_property = property::connected_neurons_post();

template<typename Executor>
void execute_n_time(std::size_t iterations, Executor && e){
    for(std::size_t i =0; i < iterations; ++i){
        e();
    }
}

template<typename Duration>
double time_to_double_seconds(const Duration & d){
    return double( std::chrono::duration_cast<std::chrono::microseconds>(d).count()) / 1000000.0;
}

void select_appropriate_population(const std::string& population_arg, synapses_reader & reader){
    std::string my_population = get_selected_population_name(population_arg, reader.list_populations());
    reader.select_population(my_population);
}

void print_stats(const std::string& population_arg, const std::string & file){
    synapses_reader reader(file);

    std::string my_population = get_selected_population_name(population_arg, reader.list_populations());
    std::cout << " -- Population selected : " << my_population << std::endl;
    reader.select_population(my_population);

    const std::size_t n_syn = reader.get_number_synapses();

    std::cout << " -- Stats : " << n_syn << " synapses" << std::endl;

}

void read_from_neuron_id(const std::string& population_arg, const std::string & file, std::size_t iterations, bool post = true){
    synapses_reader reader(file);

    select_appropriate_population(population_arg, reader);


    const std::string query_type = (post) ? "post-synaptic" : "pre-synaptic";

    std::cout << " --- Execute " << query_type << " queries with " << iterations << " iterations" << std::endl;

    std::chrono::steady_clock::duration elapsed_time(0);

    std::size_t number_row = 0;

    std::ranlux48 random_engine;
    random_engine.seed(std::time(NULL));

    std::uniform_int_distribution<std::size_t> dist(0, 999);


    execute_n_time(iterations, [&](){
        const std::size_t id = dist(random_engine);
        {
            time_counter<decltype(elapsed_time)> timer(elapsed_time);
            selection select = (post)? (selection::by_post_neuron_id(id)) : (selection::by_pre_neuron_id(id));
            auto properties = reader.get_property(test_property, select);
            try {
                vec_uint & prop_convert = boost::get<vec_uint>(properties);
                number_row += prop_convert.size();
            } catch (boost::bad_get& e) {
                vec_int & prop_convert = boost::get<vec_int>(properties);
                number_row += prop_convert.size();
            }
        }
    });

    double exec_time = time_to_double_seconds(elapsed_time);
    std::cout << " ---- Executed in: " << exec_time << "s " << std::endl;

    std::cout << " ---- Row touched: " << number_row << " rows " << std::endl;

    std::cout << " ---- Rate: " << iterations / exec_time << " queries/s " << std::endl;

    std::cout << std::endl;
}

void read_chunk_performance(const std::string& population, const std::string & file, std::size_t chunk_size, std::size_t iterations){
    synapses_reader reader(file);

    select_appropriate_population(population, reader);


    const std::size_t n_syn = reader.get_number_synapses();
    if( n_syn < chunk_size ){
        std::cout << "Not enough synapse for a range of " << chunk_size << " << reduce to chunk_size " << n_syn << std::endl;
        chunk_size = n_syn;
    }

    std::cout << " --- Execute range query of " << chunk_size << " synapses with " << iterations << " iterations" << std::endl;

    std::chrono::steady_clock::duration elapsed_time(0);

    int t_val = 0;

    std::ranlux48 random_engine;
    std::uniform_int_distribution<std::size_t> dist(0, n_syn-chunk_size);

    execute_n_time(iterations, [&](){


        const std::size_t start = dist(random_engine);

        {
            time_counter<decltype(elapsed_time)> timer(elapsed_time);
            auto properties = reader.get_property(test_property, selection::synapse_range(start, start+chunk_size));

            // dummy pickup to avoid stupid optimisations
            t_val += properties.which();
        }

    });

    double exec_time = time_to_double_seconds(elapsed_time);
    std::cout << " ---- Executed in: " << exec_time << "s " << std::endl;


    std::cout << " ---- Rate: " << iterations / exec_time << " queries/s " << std::endl;


    std::cout << std::endl;
}

void performance_syn_test(const std::string & source, const std::string& population_arg){
    const std::size_t iterations = 1000;

    std::cout << "- Evaluate performance for file " << source << std::endl;
    print_stats(population_arg, source);
    std::cout << std::endl;

    std::cout << " -- Range query bench" << std::endl << std::endl;
    read_chunk_performance(population_arg, source, 1024, iterations);
    read_chunk_performance(population_arg, source, 16384, iterations);
    read_chunk_performance(population_arg, source, 262144, iterations);
    std::cout << std::endl;

    std::cout << " -- Post-Synaptic Query bench" << std::endl << std::endl;
    read_from_neuron_id(population_arg, source, iterations);
    std::cout << std::endl;

    std::cout << " -- Pre-Synaptic Query bench" << std::endl << std::endl;
    read_from_neuron_id(population_arg, source, iterations, false);
    std::cout << std::endl;
}
