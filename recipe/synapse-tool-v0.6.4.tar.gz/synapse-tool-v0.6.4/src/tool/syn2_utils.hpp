#ifndef SYN2_UTILS_HPP
#define SYN2_UTILS_HPP

#include <string> // std::string
#include <vector> // std::vector

#include <syn2/synapses_properties.hpp>
#include <syn2/synapses_exceptions.hpp>

namespace syn2 {

inline std::string get_selected_population_name(const std::string& population_arg,
                                                const std::vector<std::string>& existing_populations){
    if (!population_arg.empty()) {
        return population_arg;
    }

    if (existing_populations.size() == 1){
        return existing_populations[0];
    }

    for (const std::string& pop : existing_populations){
        if (pop.compare(population::default_population())){
            return pop;
        }
    }
    throw syn_exception(error_code::population_not_existing,
                        "selected synapse population not existing or default population not found");
}
} // namespace syn2
#endif // SYN2_UTILS_HPP
