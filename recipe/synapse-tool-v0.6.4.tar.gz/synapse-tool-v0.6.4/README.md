# Overview

SYN-TOOL provides a C++ and a python API to read / write neuron connectivity informations

SYN-TOOL manages the following file format :

* SYN2: [HDF5 based Open File format Specification](https://github.com/adevress/syn2_spec)
* NRN (Legacy Blue Brain Project synapse file format)

SYN-TOOL is designed to support large connectivity data with billions of connections.


# Compilation

Use [Spack](https://github.com/BlueBrain/spack).

## C++

```bash
// dependencies list
// - libhdf5 (https://support.hdfgroup.org/HDF5/)
// - boost (http://www.boost.org/)
// - HighFive (https://github.com/BlueBrain/HighFive)
// - libSONATA (https://github.com/BlueBrain/libsonata)


// fetch submodule if not done yet
git submodule update --recursive --init

// create build directory
mkdir build
cd build

// configure
cmake ../

// build
make

// install
make install
```


# Usage

See [example](./src/example/) sub-directory for more informations.


# Version log

## v0.6.4
  - Faster indexing via MPI by batching more
  - Switch NRN conversion to SONATA, skip SYN2

## v0.6.3
  - Adjust to new HighFive API

## v0.6.2
  - Require newer HighFive and dump dataset paths from it

## v0.6.1
  - Indexing via `syn-tool` will now work on SONATA files only
  - Virtual properties will be skipped when sorting

## v0.6.0
  - Add the numerical index of synapses as a virtual property

## v0.3
  - Added support for GapJunctions fields with NRN
  - Improved consistency between NRN and Syn2. non-exitent gid: ok
  - Better detection of circuit files

## v0.2
  - Parallel indexing with MPI
  - Improved compatibility and read performance of the Nrn format

## v0.1
  - Initial version with support for reading Nrn and Syn2 formats, and
  writing Syn2.
  - Includes tools to read both formats and convert Nrn->Syn2


# Contributors

* Adrien Devresse - <adrien.devresse@epfl.ch>
* Fernando Pereira - <fernando.pereira@epfl.ch>
