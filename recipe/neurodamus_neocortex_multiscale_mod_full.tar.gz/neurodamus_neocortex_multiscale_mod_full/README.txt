Neocortex mechanisms
--------------------

The mods in this folder are split into v5 and v6.
Note that some of the mods are shared and therefore are sym-linked from a 'common' folder.

To build use nrnivmodl <folder>


