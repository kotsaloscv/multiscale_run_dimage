import numpy as np
from mpi4py import MPI as mpi
from utils import mpi_mem, mpi_timer
from petsc4py import PETSc

MPI_COMM = mpi.COMM_WORLD
MPI_RANK = MPI_COMM.Get_rank()
MPI_SIZE = MPI_COMM.Get_size()

n = int(5e8)

with mpi_mem.region("PETSc"), mpi_timer.region("PETSc"):
    V = PETSc.Vec()
    V.create(MPI_COMM)
    V.setSizes(n)
    V.setFromOptions()
    istart, iend = V.getOwnershipRange()
V.destroy()

with mpi_mem.region("randn"), mpi_timer.region("randn"):
    a = np.random.randn(iend-istart, 1)

mpi_timer.print()
mpi_mem.print()
