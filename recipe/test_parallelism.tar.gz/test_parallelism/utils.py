"""Utils functions."""
import sys
import time
from contextlib import contextmanager
import numpy as np
import psutil
from mpi4py import MPI


class mpi_timer:
    """A simple mpi timer class"""

    _timings = dict()

    @contextmanager
    def region(var):
        start = time.time()
        yield
        elapsed = time.time() - start
        if var in mpi_timer._timings:
            mpi_timer._timings[var][0] += elapsed
            mpi_timer._timings[var][1] += 1
        else:
            mpi_timer._timings[var] = [elapsed, 1]

    @staticmethod
    def print():
        comm = MPI.COMM_WORLD
        nRanks = comm.Get_size()
        myRank = comm.Get_rank()

        # let everyone flush to get a clean output
        sys.stdout.flush()
        comm.Barrier()

        llbl = 0
        for reg in mpi_timer._timings:
            llbl = max(len(reg), llbl)

        if myRank == 0:
            print("")
            print(80 * "-")
            print("Time report [sec]")
            print(80 * "-")
            print(80 * "-")
            print(
                "region",
                (llbl - 6) * " ",
                "max",
                12 * " ",
                "min",
                12 * " ",
                "ave",
                12 * " ",
                "times",
            )
            print(80 * "-")

        for reg in mpi_timer._timings:
            region = np.zeros(1)
            region[0] = mpi_timer._timings[reg][0]
            count = mpi_timer._timings[reg][1]
            region_max = np.zeros(1)
            comm.Reduce(region, region_max, op=MPI.MAX, root=0)
            region_min = np.zeros(1)
            comm.Reduce(region, region_min, op=MPI.MIN, root=0)
            region_ave = np.zeros(1)
            comm.Reduce(region, region_ave, op=MPI.SUM, root=0)
            region_ave /= nRanks

            if myRank == 0:
                s = f'{reg}{(llbl-len(reg))*" "}{region_max[0]:17.3f}'
                s += f"{region_min[0]:17.3f}{region_ave[0]:17.3f}{count:7d}"
                print(s)

        if myRank == 0:
            print(80 * "-")
            print("")


class mpi_mem:
    """A simple mpi memory profiler class"""

    _mem = dict()

    @contextmanager
    def region(var):
        # Memory profiling in MB -> 1024**2
        start = psutil.Process().memory_info().rss / 1024**2
        yield
        elapsed = psutil.Process().memory_info().rss / 1024**2 - start
        if var in mpi_mem._mem:
            mpi_mem._mem[var][0] += elapsed
            mpi_mem._mem[var][1] += 1
        else:
            mpi_mem._mem[var] = [elapsed, 1]

    @staticmethod
    def print():
        comm = MPI.COMM_WORLD
        myRank = comm.Get_rank()

        # let everyone flush to get a clean output
        sys.stdout.flush()
        comm.Barrier()

        llbl = 0
        for reg in mpi_mem._mem:
            llbl = max(len(reg), llbl)

        if myRank == 0:
            print("")
            print(80 * "-")
            print("Memory report [MB]")
            print(80 * "-")
            print(
                "region",
                (llbl - 6) * " ",
                "max",
                12 * " ",
                "min",
                12 * " ",
                "sum",
                12 * " ",
                "times",
            )
            print(80 * "-")

        for reg in mpi_mem._mem:
            region = np.zeros(1)
            region[0] = mpi_mem._mem[reg][0]
            count = mpi_mem._mem[reg][1]
            region_max = np.zeros(1)
            comm.Reduce(region, region_max, op=MPI.MAX, root=0)
            region_min = np.zeros(1)
            comm.Reduce(region, region_min, op=MPI.MIN, root=0)
            region_sum = np.zeros(1)
            comm.Reduce(region, region_sum, op=MPI.SUM, root=0)

            if myRank == 0:
                s = f'{reg}{(llbl-len(reg))*" "}{region_max[0]:17.3f}'
                s += f"{region_min[0]:17.3f}{region_sum[0]:17.3f}{count:7d}"
                print(s)

        if myRank == 0:
            print(80 * "-")
            print("")
